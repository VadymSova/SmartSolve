import 'package:flutter/material.dart';

import '../presentation/home_screen/home_screen.dart';
import '../presentation/settings_screen/settings_screen.dart';
import '../presentation/sign_up_login_screen/sign_up_login_screen.dart';
import '../presentation/camera_screen/camera_screen.dart';
import '../presentation/logs_dashboard_screen/logs_dashboard_screen.dart';
import '../presentation/analytics_dashboard_screen/analytics_dashboard_screen.dart';
import '../presentation/payment_confirmation_screen/payment_confirmation_screen.dart';

class AppRoutes {
  static const String initial = '/';
  static const String homeScreen = '/home-screen';
  static const String signUpLoginScreen = '/sign-up-login-screen';
  static const String settingsScreen = '/settings-screen';
  static const String cameraScreen = '/camera-screen';
  static const String logsDashboardScreen = '/logs-dashboard';
  static const String analyticsDashboardScreen = '/analytics-dashboard';
  static const String paymentConfirmationScreen = '/payment-confirmation';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SignUpLoginScreen(),
    homeScreen: (context) => const HomeScreen(),
    signUpLoginScreen: (context) => const SignUpLoginScreen(),
    settingsScreen: (context) => const SettingsScreen(),
    cameraScreen: (context) => const CameraScreen(),
    logsDashboardScreen: (context) => const LogsDashboardScreen(),
    analyticsDashboardScreen: (context) => const AnalyticsDashboardScreen(),
    paymentConfirmationScreen: (context) => const PaymentConfirmationScreen(),
  };
}
