import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../theme/app_theme.dart';
import '../../services/analytics_service.dart';

class AnalyticsDashboardScreen extends StatefulWidget {
  const AnalyticsDashboardScreen({super.key});

  @override
  State<AnalyticsDashboardScreen> createState() =>
      _AnalyticsDashboardScreenState();
}

class _AnalyticsDashboardScreenState extends State<AnalyticsDashboardScreen>
    with SingleTickerProviderStateMixin {
  bool _isLoading = true;
  int _selectedDays = 7;
  int _selectedTab = 0; // 0=Overview 1=Cohorts 2=Funnel 3=Attribution

  Map<String, int> _eventCounts = {};
  Map<String, dynamic> _sessionSummary = {};
  List<Map<String, dynamic>> _recentEvents = [];
  List<Map<String, dynamic>> _cohortData = [];
  List<Map<String, dynamic>> _coreFunnelData = [];
  List<Map<String, dynamic>> _purchaseFunnelData = [];
  Map<String, dynamic> _purchaseConversion = {};
  List<Map<String, dynamic>> _attributionData = [];

  String? _filterType;

  late AnimationController _fadeCtrl;
  late Animation<double> _fade;

  static const List<int> _dayOptions = [1, 7, 30];

  static const List<_EventFilter> _filters = [
    _EventFilter(label: 'All', value: null, icon: Icons.all_inclusive_rounded),
    _EventFilter(
      label: 'Auth',
      value: 'auth_sign_in',
      icon: Icons.login_rounded,
    ),
    _EventFilter(
      label: 'Solves',
      value: 'solve_completed',
      icon: Icons.auto_fix_high_rounded,
    ),
    _EventFilter(
      label: 'Purchases',
      value: 'purchase_completed',
      icon: Icons.diamond_rounded,
    ),
    _EventFilter(
      label: 'Errors',
      value: 'error_api',
      icon: Icons.error_rounded,
    ),
  ];

  static const List<String> _tabs = [
    'Overview',
    'Cohorts',
    'Funnel',
    'Attribution',
  ];

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    )..forward();
    _fade = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _loadData();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final results = await Future.wait([
      AnalyticsService.instance.fetchEventCounts(days: _selectedDays),
      AnalyticsService.instance.fetchSessionSummary(days: _selectedDays),
      AnalyticsService.instance.fetchRecentEvents(
        limit: 60,
        filterType: _filterType,
      ),
      AnalyticsService.instance.fetchCohortData(weeks: 8),
      AnalyticsService.instance.fetchFunnelData(
        funnelName: 'core_conversion',
        days: _selectedDays,
      ),
      AnalyticsService.instance.fetchFunnelData(
        funnelName: 'purchase_funnel',
        days: _selectedDays,
      ),
      AnalyticsService.instance.fetchPurchaseConversionSummary(
        days: _selectedDays,
      ),
      AnalyticsService.instance.fetchAttributionData(days: 30),
    ]);

    if (!mounted) return;
    setState(() {
      _eventCounts = results[0] as Map<String, int>;
      _sessionSummary = results[1] as Map<String, dynamic>;
      _recentEvents = results[2] as List<Map<String, dynamic>>;
      _cohortData = results[3] as List<Map<String, dynamic>>;
      _coreFunnelData = results[4] as List<Map<String, dynamic>>;
      _purchaseFunnelData = results[5] as List<Map<String, dynamic>>;
      _purchaseConversion = results[6] as Map<String, dynamic>;
      _attributionData = results[7] as List<Map<String, dynamic>>;
      _isLoading = false;
    });
  }

  int _sumEvents(List<String> keys) {
    return keys.fold(0, (sum, k) => sum + (_eventCounts[k] ?? 0));
  }

  String _formatDuration(int secs) {
    if (secs < 60) return '${secs}s';
    final m = secs ~/ 60;
    final s = secs % 60;
    return '${m}m ${s}s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fade,
          child: Column(
            children: [
              _buildAppBar(),
              _buildTabBar(),
              _buildDaySelector(),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                          color: AppTheme.primary,
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _loadData,
                        color: AppTheme.primary,
                        backgroundColor: AppTheme.surfaceDark,
                        child: ListView(
                          physics: const BouncingScrollPhysics(
                            parent: AlwaysScrollableScrollPhysics(),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          children: [
                            if (_selectedTab == 0) ..._buildOverviewTab(),
                            if (_selectedTab == 1) ..._buildCohortsTab(),
                            if (_selectedTab == 2) ..._buildFunnelTab(),
                            if (_selectedTab == 3) ..._buildAttributionTab(),
                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.primary.withAlpha(38), AppTheme.backgroundDark],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.primary.withAlpha(51),
                  width: 1,
                ),
              ),
              child: const Icon(
                Icons.arrow_back_ios_rounded,
                size: 18,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Analytics',
                  style: GoogleFonts.outfit(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                Text(
                  'Cohorts · Funnels · Attribution',
                  style: GoogleFonts.outfit(
                    fontSize: 12,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _loadData,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.refresh_rounded,
                size: 20,
                color: AppTheme.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      height: 40,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: AppTheme.surfaceVariantDark,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: List.generate(_tabs.length, (i) {
          final isSelected = i == _selectedTab;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedTab = i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: isSelected ? AppTheme.primary : Colors.transparent,
                  borderRadius: BorderRadius.circular(9),
                ),
                alignment: Alignment.center,
                child: Text(
                  _tabs[i],
                  style: GoogleFonts.outfit(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: isSelected ? Colors.white : AppTheme.textMuted,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildDaySelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: _dayOptions.map((d) {
          final isSelected = d == _selectedDays;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () {
                if (_selectedDays != d) {
                  setState(() => _selectedDays = d);
                  _loadData();
                }
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.primary
                      : AppTheme.surfaceVariantDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected
                        ? AppTheme.primary
                        : AppTheme.primary.withAlpha(40),
                    width: 1,
                  ),
                ),
                child: Text(
                  d == 1 ? '24h' : '${d}d',
                  style: GoogleFonts.outfit(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isSelected ? Colors.white : AppTheme.textSecondary,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ── Overview Tab ──────────────────────────────────────────────────────────

  List<Widget> _buildOverviewTab() {
    return [
      _buildSessionSummary(),
      const SizedBox(height: 16),
      _buildEngagementStats(),
      const SizedBox(height: 16),
      _buildDropOffStats(),
      const SizedBox(height: 16),
      _buildEventFeed(),
    ];
  }

  Widget _buildSessionSummary() {
    final sessions = _sessionSummary['sessions'] as int? ?? 0;
    final avgDuration = _sessionSummary['avg_duration'] as int? ?? 0;
    final totalSolves = _sessionSummary['total_solves'] as int? ?? 0;
    final totalErrors = _sessionSummary['total_errors'] as int? ?? 0;

    return _SectionCard(
      title: 'Session Metrics',
      icon: Icons.timeline_rounded,
      iconColor: AppTheme.primary,
      child: Row(
        children: [
          _MetricTile(
            label: 'Sessions',
            value: '$sessions',
            icon: Icons.people_rounded,
            color: AppTheme.primary,
          ),
          _MetricTile(
            label: 'Avg Duration',
            value: _formatDuration(avgDuration),
            icon: Icons.timer_rounded,
            color: const Color(0xFF06B6D4),
          ),
          _MetricTile(
            label: 'Solves',
            value: '$totalSolves',
            icon: Icons.auto_fix_high_rounded,
            color: AppTheme.success,
          ),
          _MetricTile(
            label: 'Errors',
            value: '$totalErrors',
            icon: Icons.error_rounded,
            color: AppTheme.error,
          ),
        ],
      ),
    );
  }

  Widget _buildEngagementStats() {
    final signIns = _sumEvents(['auth_sign_in', 'auth_sign_up']);
    final solveStarts = _eventCounts['solve_started'] ?? 0;
    final solveCompletes = _eventCounts['solve_completed'] ?? 0;
    final purchases = _eventCounts['purchase_completed'] ?? 0;
    final cameraOpens = _eventCounts['camera_opened'] ?? 0;

    final solveRate = solveStarts > 0
        ? ((solveCompletes / solveStarts) * 100).round()
        : 0;

    return _SectionCard(
      title: 'Engagement Funnel',
      icon: Icons.help_outline,
      iconColor: const Color(0xFF8B5CF6),
      child: Column(
        children: [
          _FunnelRow(
            label: 'Auth Events',
            value: signIns,
            icon: Icons.login_rounded,
            color: AppTheme.primary,
          ),
          _FunnelRow(
            label: 'Camera Opens',
            value: cameraOpens,
            icon: Icons.camera_alt_rounded,
            color: const Color(0xFF06B6D4),
          ),
          _FunnelRow(
            label: 'Solves Started',
            value: solveStarts,
            icon: Icons.play_circle_rounded,
            color: const Color(0xFF8B5CF6),
          ),
          _FunnelRow(
            label: 'Solves Completed',
            value: solveCompletes,
            icon: Icons.check_circle_rounded,
            color: AppTheme.success,
            badge: solveStarts > 0 ? '$solveRate% rate' : null,
          ),
          _FunnelRow(
            label: 'Purchases',
            value: purchases,
            icon: Icons.diamond_rounded,
            color: AppTheme.crystalAccent,
          ),
        ],
      ),
    );
  }

  Widget _buildDropOffStats() {
    final solveStarts = _eventCounts['solve_started'] ?? 0;
    final solveFails = _eventCounts['solve_failed'] ?? 0;
    final solveRetries = _eventCounts['solve_retried'] ?? 0;
    final authErrors = _eventCounts['auth_error'] ?? 0;
    final purchaseFails = _eventCounts['purchase_failed'] ?? 0;
    final purchaseCancels = _eventCounts['purchase_cancelled'] ?? 0;
    final networkErrors = _sumEvents(['error_network', 'error_api']);
    final crashes = _eventCounts['error_crash'] ?? 0;

    return _SectionCard(
      title: 'Drop-off Points',
      icon: Icons.trending_down_rounded,
      iconColor: AppTheme.error,
      child: Column(
        children: [
          _DropOffRow(
            label: 'Auth Failures',
            value: authErrors,
            total: _sumEvents(['auth_sign_in', 'auth_sign_up', 'auth_error']),
            color: AppTheme.error,
          ),
          _DropOffRow(
            label: 'Solve Failures',
            value: solveFails,
            total: solveStarts,
            color: const Color(0xFFF59E0B),
          ),
          _DropOffRow(
            label: 'Solve Retries',
            value: solveRetries,
            total: solveStarts,
            color: const Color(0xFF8B5CF6),
          ),
          _DropOffRow(
            label: 'Purchase Failures',
            value: purchaseFails + purchaseCancels,
            total: _sumEvents([
              'purchase_started',
              'purchase_completed',
              'purchase_failed',
              'purchase_cancelled',
            ]),
            color: AppTheme.error,
          ),
          _DropOffRow(
            label: 'Network / API Errors',
            value: networkErrors,
            total: null,
            color: const Color(0xFFF59E0B),
          ),
          _DropOffRow(
            label: 'Crashes',
            value: crashes,
            total: null,
            color: AppTheme.error,
          ),
        ],
      ),
    );
  }

  Widget _buildEventFeed() {
    return _SectionCard(
      title: 'Recent Events',
      icon: Icons.receipt_long_rounded,
      iconColor: const Color(0xFF06B6D4),
      headerTrailing: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: _filters.map((f) {
            final isSelected = _filterType == f.value;
            return Padding(
              padding: const EdgeInsets.only(left: 6),
              child: GestureDetector(
                onTap: () {
                  setState(() => _filterType = f.value);
                  _loadData();
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.primary.withAlpha(40)
                        : AppTheme.surfaceVariantDark,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isSelected ? AppTheme.primary : Colors.transparent,
                      width: 1,
                    ),
                  ),
                  child: Text(
                    f.label,
                    style: GoogleFonts.outfit(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? AppTheme.primary : AppTheme.textMuted,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
      child: _recentEvents.isEmpty
          ? Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Center(
                child: Text(
                  'No events yet',
                  style: GoogleFonts.outfit(
                    color: AppTheme.textMuted,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          : Column(
              children: _recentEvents
                  .take(30)
                  .map((e) => _EventRow(event: e))
                  .toList(),
            ),
    );
  }

  // ── Cohorts Tab ───────────────────────────────────────────────────────────

  List<Widget> _buildCohortsTab() {
    return [
      _SectionCard(
        title: 'User Cohorts (by signup week)',
        icon: Icons.group_rounded,
        iconColor: const Color(0xFF8B5CF6),
        child: _cohortData.isEmpty
            ? _emptyState('No cohort data yet')
            : Column(
                children: [
                  // Header row
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: Text(
                            'Week',
                            style: GoogleFonts.outfit(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textMuted,
                            ),
                          ),
                        ),
                        _cohortHeader('Users'),
                        _cohortHeader('Activated'),
                        _cohortHeader('Converted'),
                        _cohortHeader('Revenue'),
                      ],
                    ),
                  ),
                  Divider(height: 1, color: AppTheme.primary.withAlpha(20)),
                  const SizedBox(height: 8),
                  ..._cohortData.take(8).map((c) => _CohortRow(cohort: c)),
                ],
              ),
      ),
    ];
  }

  Widget _cohortHeader(String label) {
    return Expanded(
      flex: 2,
      child: Text(
        label,
        style: GoogleFonts.outfit(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: AppTheme.textMuted,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  // ── Funnel Tab ────────────────────────────────────────────────────────────

  List<Widget> _buildFunnelTab() {
    final convRate = _purchaseConversion['conversion_rate'] as int? ?? 0;
    final revenue = (_purchaseConversion['total_revenue'] as num? ?? 0)
        .toDouble();
    final started = _purchaseConversion['started'] as int? ?? 0;
    final completed = _purchaseConversion['completed'] as int? ?? 0;
    final failed = _purchaseConversion['failed'] as int? ?? 0;
    final cancelled = _purchaseConversion['cancelled'] as int? ?? 0;

    return [
      // Core conversion funnel
      _SectionCard(
        title: 'Core Conversion Funnel',
        icon: Icons.filter_alt_rounded,
        iconColor: AppTheme.primary,
        child: _coreFunnelData.isEmpty
            ? _emptyState('No funnel data yet')
            : _FunnelChart(steps: _coreFunnelData),
      ),
      const SizedBox(height: 16),
      // Purchase funnel
      _SectionCard(
        title: 'Purchase Funnel',
        icon: Icons.shopping_cart_rounded,
        iconColor: AppTheme.crystalAccent,
        child: _purchaseFunnelData.isEmpty
            ? _emptyState('No purchase funnel data yet')
            : _FunnelChart(steps: _purchaseFunnelData),
      ),
      const SizedBox(height: 16),
      // Purchase conversion summary
      _SectionCard(
        title: 'Purchase Conversion',
        icon: Icons.diamond_rounded,
        iconColor: AppTheme.crystalAccent,
        child: Column(
          children: [
            Row(
              children: [
                _MetricTile(
                  label: 'Started',
                  value: '$started',
                  icon: Icons.shopping_cart_rounded,
                  color: AppTheme.primary,
                ),
                _MetricTile(
                  label: 'Completed',
                  value: '$completed',
                  icon: Icons.check_circle_rounded,
                  color: AppTheme.success,
                ),
                _MetricTile(
                  label: 'Failed',
                  value: '$failed',
                  icon: Icons.cancel_rounded,
                  color: AppTheme.error,
                ),
                _MetricTile(
                  label: 'Cancelled',
                  value: '$cancelled',
                  icon: Icons.close_rounded,
                  color: const Color(0xFFF59E0B),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Conversion Rate',
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          color: AppTheme.textMuted,
                        ),
                      ),
                      Text(
                        '$convRate%',
                        style: GoogleFonts.outfit(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: convRate > 0
                              ? AppTheme.success
                              : AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Total Revenue',
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          color: AppTheme.textMuted,
                        ),
                      ),
                      Text(
                        '\$${revenue.toStringAsFixed(2)}',
                        style: GoogleFonts.outfit(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.crystalAccent,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ];
  }

  // ── Attribution Tab ───────────────────────────────────────────────────────

  List<Widget> _buildAttributionTab() {
    return [
      _SectionCard(
        title: 'Campaign Attribution (last 30d)',
        icon: Icons.campaign_rounded,
        iconColor: const Color(0xFF06B6D4),
        child: _attributionData.isEmpty
            ? _emptyState(
                'No attribution data yet.\nUTM params are captured on first app open.',
              )
            : Column(
                children: [
                  // Header
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 3,
                          child: Text(
                            'Source',
                            style: GoogleFonts.outfit(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textMuted,
                            ),
                          ),
                        ),
                        _cohortHeader('Installs'),
                        _cohortHeader('Conversions'),
                        _cohortHeader('CVR'),
                      ],
                    ),
                  ),
                  Divider(height: 1, color: AppTheme.primary.withAlpha(20)),
                  const SizedBox(height: 8),
                  ..._attributionData
                      .take(10)
                      .map((a) => _AttributionRow(data: a)),
                ],
              ),
      ),
      const SizedBox(height: 16),
      _SectionCard(
        title: 'How UTM Attribution Works',
        icon: Icons.info_outline_rounded,
        iconColor: AppTheme.textMuted,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _infoRow(
              Icons.first_page_rounded,
              'Captured on first open',
              'UTM params from deep links are stored once per install',
            ),
            const SizedBox(height: 10),
            _infoRow(
              Icons.link_rounded,
              'Linked to conversions',
              'Purchase completions are automatically tied to the source campaign',
            ),
            const SizedBox(height: 10),
            _infoRow(
              Icons.storage_rounded,
              'Persisted in Supabase',
              'campaign_attributions table stores source, medium, campaign, term, content',
            ),
          ],
        ),
      ),
    ];
  }

  Widget _infoRow(IconData icon, String title, String subtitle) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            color: AppTheme.primary.withAlpha(30),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 14, color: AppTheme.primary),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.outfit(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
              ),
              Text(
                subtitle,
                style: GoogleFonts.outfit(
                  fontSize: 11,
                  color: AppTheme.textMuted,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _emptyState(String message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Center(
        child: Text(
          message,
          style: GoogleFonts.outfit(color: AppTheme.textMuted, fontSize: 13),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

// ── Supporting Widgets ────────────────────────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color iconColor;
  final Widget child;
  final Widget? headerTrailing;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.iconColor,
    required this.child,
    this.headerTrailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primary.withAlpha(30), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: iconColor.withAlpha(30),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, size: 16, color: iconColor),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: GoogleFonts.outfit(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                ),
                if (headerTrailing != null) headerTrailing!,
              ],
            ),
          ),
          Divider(height: 1, color: AppTheme.primary.withAlpha(20)),
          Padding(padding: const EdgeInsets.all(14), child: child),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _MetricTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 18, color: color),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: GoogleFonts.outfit(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: AppTheme.textPrimary,
            ),
          ),
          Text(
            label,
            style: GoogleFonts.outfit(fontSize: 10, color: AppTheme.textMuted),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class _FunnelRow extends StatelessWidget {
  final String label;
  final int value;
  final IconData icon;
  final Color color;
  final String? badge;

  const _FunnelRow({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 14, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              style: GoogleFonts.outfit(
                fontSize: 13,
                color: AppTheme.textSecondary,
              ),
            ),
          ),
          if (badge != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: AppTheme.success.withAlpha(30),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                badge!,
                style: GoogleFonts.outfit(
                  fontSize: 10,
                  color: AppTheme.success,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Text(
            '$value',
            style: GoogleFonts.outfit(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}

class _DropOffRow extends StatelessWidget {
  final String label;
  final int value;
  final int? total;
  final Color color;

  const _DropOffRow({
    required this.label,
    required this.value,
    required this.total,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final pct = (total != null && total! > 0)
        ? ((value / total!) * 100).round()
        : null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        label,
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      pct != null ? '$value ($pct%)' : '$value',
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: value > 0 ? color : AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: (total != null && total! > 0)
                        ? (value / total!).clamp(0.0, 1.0)
                        : 0,
                    minHeight: 4,
                    backgroundColor: AppTheme.surfaceVariantDark,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      value > 0
                          ? color.withAlpha(180)
                          : AppTheme.surfaceVariantDark,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FunnelChart extends StatelessWidget {
  final List<Map<String, dynamic>> steps;

  const _FunnelChart({required this.steps});

  static const List<Color> _stepColors = [
    AppTheme.primary,
    Color(0xFF8B5CF6),
    Color(0xFF06B6D4),
    AppTheme.success,
    AppTheme.crystalAccent,
  ];

  @override
  Widget build(BuildContext context) {
    final maxCount = steps.fold<int>(
      0,
      (m, s) => (s['count'] as int? ?? 0) > m ? (s['count'] as int) : m,
    );

    return Column(
      children: List.generate(steps.length, (i) {
        final step = steps[i];
        final count = step['count'] as int? ?? 0;
        final name = (step['step_name'] as String? ?? '').replaceAll('_', ' ');
        final color = _stepColors[i % _stepColors.length];
        final ratio = maxCount > 0 ? count / maxCount : 0.0;

        // Drop-off from previous step
        String? dropOff;
        if (i > 0) {
          final prevCount = steps[i - 1]['count'] as int? ?? 0;
          if (prevCount > 0) {
            final pct = ((count / prevCount) * 100).round();
            dropOff = '$pct% from prev';
          }
        }

        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 20,
                    height: 20,
                    decoration: BoxDecoration(
                      color: color.withAlpha(40),
                      shape: BoxShape.circle,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      '${i + 1}',
                      style: GoogleFonts.outfit(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: color,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      name,
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        color: AppTheme.textSecondary,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (dropOff != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceVariantDark,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        dropOff,
                        style: GoogleFonts.outfit(
                          fontSize: 10,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    ),
                  const SizedBox(width: 8),
                  Text(
                    '$count',
                    style: GoogleFonts.outfit(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: ratio.clamp(0.0, 1.0),
                  minHeight: 5,
                  backgroundColor: AppTheme.surfaceVariantDark,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    color.withAlpha(180),
                  ),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

class _CohortRow extends StatelessWidget {
  final Map<String, dynamic> cohort;

  const _CohortRow({required this.cohort});

  @override
  Widget build(BuildContext context) {
    final week = cohort['cohort_week'] as String? ?? '-';
    final users = cohort['users'] as int? ?? 0;
    final activated = cohort['activated'] as int? ?? 0;
    final converted = cohort['converted'] as int? ?? 0;
    final revenue = (cohort['total_spent_usd'] as num? ?? 0).toDouble();

    final activationRate = users > 0 ? ((activated / users) * 100).round() : 0;
    final conversionRate = users > 0 ? ((converted / users) * 100).round() : 0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              week,
              style: GoogleFonts.outfit(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '$users',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: AppTheme.textSecondary,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '$activationRate%',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: activationRate > 0
                    ? AppTheme.success
                    : AppTheme.textMuted,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '$conversionRate%',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: conversionRate > 0
                    ? AppTheme.crystalAccent
                    : AppTheme.textMuted,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '\$${revenue.toStringAsFixed(0)}',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: revenue > 0
                    ? AppTheme.crystalAccent
                    : AppTheme.textMuted,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

class _AttributionRow extends StatelessWidget {
  final Map<String, dynamic> data;

  const _AttributionRow({required this.data});

  @override
  Widget build(BuildContext context) {
    final source = data['utm_source'] as String? ?? 'organic';
    final installs = data['installs'] as int? ?? 0;
    final conversions = data['conversions'] as int? ?? 0;
    final cvr = installs > 0 ? ((conversions / installs) * 100).round() : 0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Row(
              children: [
                Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withAlpha(30),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(
                    Icons.campaign_rounded,
                    size: 12,
                    color: AppTheme.primary,
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    source,
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '$installs',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: AppTheme.textSecondary,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '$conversions',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: conversions > 0 ? AppTheme.success : AppTheme.textMuted,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              '$cvr%',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: cvr > 0 ? AppTheme.crystalAccent : AppTheme.textMuted,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

class _EventRow extends StatelessWidget {
  final Map<String, dynamic> event;

  const _EventRow({required this.event});

  Color _colorForType(String type) {
    if (type.startsWith('auth')) return AppTheme.primary;
    if (type.startsWith('solve')) return AppTheme.success;
    if (type.startsWith('purchase')) return AppTheme.crystalAccent;
    if (type.startsWith('camera') || type.startsWith('gallery')) {
      return const Color(0xFF06B6D4);
    }
    if (type.startsWith('error') || type.startsWith('session')) {
      return AppTheme.error;
    }
    return AppTheme.textMuted;
  }

  IconData _iconForType(String type) {
    if (type.startsWith('auth_sign_in')) return Icons.login_rounded;
    if (type.startsWith('auth_sign_up')) return Icons.person_add_rounded;
    if (type.startsWith('auth_sign_out')) return Icons.logout_rounded;
    if (type.startsWith('auth_error')) return Icons.lock_rounded;
    if (type.startsWith('solve_completed')) return Icons.check_circle_rounded;
    if (type.startsWith('solve_failed')) return Icons.cancel_rounded;
    if (type.startsWith('solve_started')) return Icons.play_circle_rounded;
    if (type.startsWith('solve_retried')) return Icons.replay_rounded;
    if (type.startsWith('camera_opened')) return Icons.camera_alt_rounded;
    if (type.startsWith('camera_captured')) return Icons.photo_camera_rounded;
    if (type.startsWith('gallery_picked')) return Icons.photo_library_rounded;
    if (type.startsWith('purchase_completed')) return Icons.diamond_rounded;
    if (type.startsWith('purchase_started')) return Icons.shopping_cart_rounded;
    if (type.startsWith('purchase_failed')) return Icons.money_off_rounded;
    if (type.startsWith('purchase_cancelled')) return Icons.cancel_rounded;
    if (type.startsWith('error_crash')) return Icons.bug_report_rounded;
    if (type.startsWith('error_api')) return Icons.cloud_off_rounded;
    if (type.startsWith('error_network')) return Icons.wifi_off_rounded;
    if (type.startsWith('session')) return Icons.timeline_rounded;
    return Icons.circle_rounded;
  }

  String _formatTime(String? iso) {
    if (iso == null) return '';
    try {
      final dt = DateTime.parse(iso).toLocal();
      final now = DateTime.now();
      final diff = now.difference(dt);
      if (diff.inMinutes < 1) return 'just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${diff.inDays}d ago';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final type = event['event_type'] as String? ?? 'unknown';
    final color = _colorForType(type);
    final icon = _iconForType(type);
    final createdAt = event['created_at'] as String?;
    final platform = event['platform'] as String? ?? '';
    final props = event['properties'] as Map<String, dynamic>?;

    String subtitle = platform;
    if (props != null && props.isNotEmpty) {
      final parts = props.entries
          .where((e) => e.key != 'session_id')
          .take(2)
          .map((e) => '${e.key}: ${e.value}')
          .join(' · ');
      if (parts.isNotEmpty) subtitle = parts;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: color.withAlpha(30),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 14, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  type.replaceAll('_', ' '),
                  style: GoogleFonts.outfit(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                if (subtitle.isNotEmpty)
                  Text(
                    subtitle,
                    style: GoogleFonts.outfit(
                      fontSize: 11,
                      color: AppTheme.textMuted,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
              ],
            ),
          ),
          Text(
            _formatTime(createdAt),
            style: GoogleFonts.outfit(fontSize: 10, color: AppTheme.textMuted),
          ),
        ],
      ),
    );
  }
}

class _EventFilter {
  final String label;
  final String? value;
  final IconData icon;

  const _EventFilter({
    required this.label,
    required this.value,
    required this.icon,
  });
}
