import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import '../../services/stripe_payment_service.dart';

class PaymentConfirmationScreen extends StatefulWidget {
  const PaymentConfirmationScreen({super.key});

  @override
  State<PaymentConfirmationScreen> createState() =>
      _PaymentConfirmationScreenState();
}

class _PaymentConfirmationScreenState extends State<PaymentConfirmationScreen>
    with TickerProviderStateMixin {
  late AnimationController _checkCtrl;
  late AnimationController _contentCtrl;
  late Animation<double> _checkScale;
  late Animation<double> _checkOpacity;
  late Animation<double> _contentFade;
  late Animation<Offset> _contentSlide;

  int _crystalBalance = 0;
  bool _isLoadingBalance = true;
  Timer? _pollTimer;
  int _pollCount = 0;
  static const int _maxPolls = 8;

  // Args passed via Navigator
  int _purchasedAmount = 0;
  String _transactionId = '';
  double _priceUsd = 0.0;

  @override
  void initState() {
    super.initState();

    _checkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _contentCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _checkScale = CurvedAnimation(parent: _checkCtrl, curve: Curves.elasticOut);
    _checkOpacity = CurvedAnimation(parent: _checkCtrl, curve: Curves.easeIn);
    _contentFade = CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOut);
    _contentSlide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOut));

    // Start animations
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _checkCtrl.forward();
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _contentCtrl.forward();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null) {
      _purchasedAmount = args['crystalAmount'] as int? ?? 0;
      _transactionId = args['transactionId'] as String? ?? '';
      _priceUsd = args['priceUsd'] as double? ?? 0.0;
    }
    _loadBalanceWithPolling();
  }

  Future<void> _loadBalanceWithPolling() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() => _isLoadingBalance = false);
      return;
    }

    // Fetch immediately
    await _fetchBalance(user.id);

    // Poll until balance reflects the purchase (webhook may take a moment)
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      _pollCount++;
      if (_pollCount >= _maxPolls || !mounted) {
        timer.cancel();
        if (mounted) setState(() => _isLoadingBalance = false);
        return;
      }
      await _fetchBalance(user.id);
    });
  }

  Future<void> _fetchBalance(String userId) async {
    try {
      final balance = await StripePaymentService.instance.getCrystalBalance(
        userId,
      );
      if (mounted) {
        setState(() {
          _crystalBalance = balance;
          _isLoadingBalance = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _isLoadingBalance = false);
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _checkCtrl.dispose();
    _contentCtrl.dispose();
    super.dispose();
  }

  void _copyTransactionId() {
    if (_transactionId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _transactionId));
    Fluttertoast.showToast(
      msg: 'Transaction ID copied',
      backgroundColor: AppTheme.surfaceElevatedDark,
      textColor: AppTheme.textPrimary,
    );
  }

  String get _displayTransactionId {
    if (_transactionId.isEmpty) return '—';
    // Show pi_XXXX...XXXX format
    if (_transactionId.length > 20) {
      return '${_transactionId.substring(0, 12)}...${_transactionId.substring(_transactionId.length - 6)}';
    }
    return _transactionId;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // ── Success badge ──────────────────────────────────────
              ScaleTransition(
                scale: _checkScale,
                child: FadeTransition(
                  opacity: _checkOpacity,
                  child: _SuccessBadge(),
                ),
              ),
              const SizedBox(height: 28),

              // ── Main content ───────────────────────────────────────
              SlideTransition(
                position: _contentSlide,
                child: FadeTransition(
                  opacity: _contentFade,
                  child: Column(
                    children: [
                      Text(
                        'Payment Confirmed!',
                        style: GoogleFonts.outfit(
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.textPrimary,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Your crystals will be credited shortly\nonce the payment is verified.',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          color: AppTheme.textSecondary,
                          height: 1.6,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 32),

                      // ── Crystal balance card ───────────────────────
                      _CrystalBalanceCard(
                        balance: _crystalBalance,
                        purchasedAmount: _purchasedAmount,
                        isLoading: _isLoadingBalance,
                      ),
                      const SizedBox(height: 16),

                      // ── Transaction details card ───────────────────
                      _TransactionCard(
                        transactionId: _displayTransactionId,
                        fullTransactionId: _transactionId,
                        crystalAmount: _purchasedAmount,
                        priceUsd: _priceUsd,
                        onCopy: _copyTransactionId,
                      ),
                      const SizedBox(height: 32),

                      // ── Webhook notice ─────────────────────────────
                      _WebhookNotice(),
                      const SizedBox(height: 32),

                      // ── CTA buttons ────────────────────────────────
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () => Navigator.pushNamedAndRemoveUntil(
                            context,
                            AppRoutes.homeScreen,
                            (route) => false,
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.primary,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            elevation: 0,
                          ),
                          child: Text(
                            'Start Solving',
                            style: GoogleFonts.outfit(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: TextButton(
                          onPressed: () => Navigator.pushNamedAndRemoveUntil(
                            context,
                            AppRoutes.settingsScreen,
                            (route) => false,
                          ),
                          style: TextButton.styleFrom(
                            foregroundColor: AppTheme.textSecondary,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                          child: Text(
                            'Back to Settings',
                            style: GoogleFonts.outfit(fontSize: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Success badge ──────────────────────────────────────────────────────────────

class _SuccessBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [Color(0xFF10B981), Color(0xFF059669)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF10B981).withAlpha(77),
            blurRadius: 28,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: const Icon(Icons.check_rounded, color: Colors.white, size: 52),
    );
  }
}

// ── Crystal balance card ───────────────────────────────────────────────────────

class _CrystalBalanceCard extends StatelessWidget {
  final int balance;
  final int purchasedAmount;
  final bool isLoading;

  const _CrystalBalanceCard({
    required this.balance,
    required this.purchasedAmount,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF3B1A78), Color(0xFF1E1B2E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.crystalAccent.withAlpha(77),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.crystalAccent.withAlpha(38),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: AppTheme.crystalGradient,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.crystalAccent.withAlpha(89),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.diamond_rounded,
              color: Colors.black,
              size: 26,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Crystal Balance',
                  style: GoogleFonts.outfit(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
                const SizedBox(height: 4),
                isLoading
                    ? SizedBox(
                        width: 80,
                        height: 28,
                        child: LinearProgressIndicator(
                          backgroundColor: AppTheme.surfaceElevatedDark,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppTheme.crystalAccent,
                          ),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      )
                    : Text(
                        '$balance',
                        style: GoogleFonts.outfit(
                          fontSize: 30,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.crystalLight,
                          fontFeatures: [const FontFeature.tabularFigures()],
                        ),
                      ),
              ],
            ),
          ),
          if (purchasedAmount > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppTheme.success.withAlpha(38),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: AppTheme.success.withAlpha(102)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.add_rounded,
                    size: 13,
                    color: AppTheme.success,
                  ),
                  const SizedBox(width: 2),
                  Text(
                    '$purchasedAmount',
                    style: GoogleFonts.outfit(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.success,
                      fontFeatures: [const FontFeature.tabularFigures()],
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ── Transaction details card ───────────────────────────────────────────────────

class _TransactionCard extends StatelessWidget {
  final String transactionId;
  final String fullTransactionId;
  final int crystalAmount;
  final double priceUsd;
  final VoidCallback onCopy;

  const _TransactionCard({
    required this.transactionId,
    required this.fullTransactionId,
    required this.crystalAmount,
    required this.priceUsd,
    required this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.surfaceElevatedDark, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Transaction Details',
            style: GoogleFonts.outfit(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
          const SizedBox(height: 16),
          _DetailRow(label: 'Pack', value: '$crystalAmount Crystals'),
          const SizedBox(height: 10),
          _DetailRow(
            label: 'Amount Paid',
            value: priceUsd > 0 ? '\$${priceUsd.toStringAsFixed(2)}' : '—',
          ),
          const SizedBox(height: 10),
          _DetailRow(
            label: 'Status',
            value: 'Confirmed',
            valueColor: AppTheme.success,
          ),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Transaction ID',
                style: GoogleFonts.outfit(
                  fontSize: 13,
                  color: AppTheme.textSecondary,
                ),
              ),
              const Spacer(),
              Flexible(
                child: Text(
                  transactionId,
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 12,
                    color: AppTheme.textPrimary,
                  ),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ),
              if (fullTransactionId.isNotEmpty) ...[
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: onCopy,
                  child: const Icon(
                    Icons.copy_rounded,
                    size: 16,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _DetailRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: GoogleFonts.outfit(
            fontSize: 13,
            color: AppTheme.textSecondary,
          ),
        ),
        Text(
          value,
          style: GoogleFonts.outfit(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: valueColor ?? AppTheme.textPrimary,
          ),
        ),
      ],
    );
  }
}

// ── Webhook notice ─────────────────────────────────────────────────────────────

class _WebhookNotice extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.info.withAlpha(20),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.info.withAlpha(51)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(
            Icons.info_outline_rounded,
            size: 16,
            color: AppTheme.info,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'Crystals are credited after Stripe confirms the payment. This usually takes a few seconds.',
              style: GoogleFonts.outfit(
                fontSize: 12,
                color: AppTheme.info,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
