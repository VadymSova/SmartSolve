import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../services/logging_service.dart';
import '../../theme/app_theme.dart';

// ── Provider ──────────────────────────────────────────────────────────────────

class LogsDashboardState {
  final List<AppLog> logs;
  final bool isLoading;
  final String? error;
  final LogCategory? filterCategory;
  final LogLevel? filterLevel;

  const LogsDashboardState({
    this.logs = const [],
    this.isLoading = false,
    this.error,
    this.filterCategory,
    this.filterLevel,
  });

  LogsDashboardState copyWith({
    List<AppLog>? logs,
    bool? isLoading,
    String? error,
    bool clearError = false,
    LogCategory? filterCategory,
    bool clearCategory = false,
    LogLevel? filterLevel,
    bool clearLevel = false,
  }) {
    return LogsDashboardState(
      logs: logs ?? this.logs,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : (error ?? this.error),
      filterCategory: clearCategory
          ? null
          : (filterCategory ?? this.filterCategory),
      filterLevel: clearLevel ? null : (filterLevel ?? this.filterLevel),
    );
  }
}

class LogsDashboardNotifier extends StateNotifier<LogsDashboardState> {
  LogsDashboardNotifier() : super(const LogsDashboardState()) {
    fetchLogs();
  }

  Future<void> fetchLogs() async {
    state = state.copyWith(isLoading: true, clearError: true);
    try {
      final logs = await LoggingService.instance.fetchLogs(limit: 100);
      state = state.copyWith(logs: logs, isLoading: false);
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Failed to load logs. Please try again.',
      );
    }
  }

  void setCategory(LogCategory? category) {
    if (category == state.filterCategory) {
      state = state.copyWith(clearCategory: true);
    } else {
      state = state.copyWith(filterCategory: category);
    }
  }

  void setLevel(LogLevel? level) {
    if (level == state.filterLevel) {
      state = state.copyWith(clearLevel: true);
    } else {
      state = state.copyWith(filterLevel: level);
    }
  }

  List<AppLog> get filteredLogs {
    return state.logs.where((log) {
      final catMatch =
          state.filterCategory == null || log.category == state.filterCategory;
      final lvlMatch =
          state.filterLevel == null || log.level == state.filterLevel;
      return catMatch && lvlMatch;
    }).toList();
  }
}

final logsDashboardProvider =
    StateNotifierProvider.autoDispose<
      LogsDashboardNotifier,
      LogsDashboardState
    >((ref) => LogsDashboardNotifier());

// ── Screen ────────────────────────────────────────────────────────────────────

class LogsDashboardScreen extends ConsumerWidget {
  const LogsDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(logsDashboardProvider);
    final notifier = ref.read(logsDashboardProvider.notifier);
    final filtered = notifier.filteredLogs;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        backgroundColor: AppTheme.backgroundDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: AppTheme.textPrimary,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Error Logs',
          style: GoogleFonts.outfit(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.refresh_rounded,
              color: AppTheme.primaryLight,
            ),
            tooltip: 'Refresh',
            onPressed: notifier.fetchLogs,
          ),
        ],
      ),
      body: Column(
        children: [
          _StatsBar(logs: state.logs),
          _FilterRow(state: state, notifier: notifier),
          Expanded(
            child: state.isLoading
                ? const Center(
                    child: CircularProgressIndicator(color: AppTheme.primary),
                  )
                : state.error != null
                ? _ErrorView(message: state.error!, onRetry: notifier.fetchLogs)
                : filtered.isEmpty
                ? _EmptyView(
                    hasFilters:
                        state.filterCategory != null ||
                        state.filterLevel != null,
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) =>
                        _LogCard(log: filtered[index]),
                  ),
          ),
        ],
      ),
    );
  }
}

// ── Stats Bar ─────────────────────────────────────────────────────────────────

class _StatsBar extends StatelessWidget {
  final List<AppLog> logs;
  const _StatsBar({required this.logs});

  @override
  Widget build(BuildContext context) {
    final crashes = logs.where((l) => l.category == LogCategory.crash).length;
    final apiErrors = logs
        .where((l) => l.category == LogCategory.apiError)
        .length;
    final userFails = logs
        .where((l) => l.category == LogCategory.userFailure)
        .length;
    final network = logs.where((l) => l.category == LogCategory.network).length;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.primary.withAlpha(38)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _StatChip(label: 'Crashes', count: crashes, color: AppTheme.error),
          _StatChip(label: 'API', count: apiErrors, color: AppTheme.warning),
          _StatChip(label: 'User', count: userFails, color: AppTheme.info),
          _StatChip(
            label: 'Network',
            count: network,
            color: AppTheme.primaryLight,
          ),
          _StatChip(
            label: 'Total',
            count: logs.length,
            color: AppTheme.textSecondary,
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final int count;
  final Color color;
  const _StatChip({
    required this.label,
    required this.count,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          count.toString(),
          style: GoogleFonts.outfit(
            color: color,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: GoogleFonts.outfit(
            color: AppTheme.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

// ── Filter Row ────────────────────────────────────────────────────────────────

class _FilterRow extends StatelessWidget {
  final LogsDashboardState state;
  final LogsDashboardNotifier notifier;
  const _FilterRow({required this.state, required this.notifier});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        children: [
          _FilterChip(
            label: 'Crashes',
            isActive: state.filterCategory == LogCategory.crash,
            color: AppTheme.error,
            onTap: () => notifier.setCategory(LogCategory.crash),
          ),
          const SizedBox(width: 8),
          _FilterChip(
            label: 'API Errors',
            isActive: state.filterCategory == LogCategory.apiError,
            color: AppTheme.warning,
            onTap: () => notifier.setCategory(LogCategory.apiError),
          ),
          const SizedBox(width: 8),
          _FilterChip(
            label: 'User Failures',
            isActive: state.filterCategory == LogCategory.userFailure,
            color: AppTheme.info,
            onTap: () => notifier.setCategory(LogCategory.userFailure),
          ),
          const SizedBox(width: 8),
          _FilterChip(
            label: 'Network',
            isActive: state.filterCategory == LogCategory.network,
            color: AppTheme.primaryLight,
            onTap: () => notifier.setCategory(LogCategory.network),
          ),
          const SizedBox(width: 8),
          _FilterChip(
            label: 'Critical',
            isActive: state.filterLevel == LogLevel.critical,
            color: AppTheme.error,
            onTap: () => notifier.setLevel(LogLevel.critical),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isActive;
  final Color color;
  final VoidCallback onTap;
  const _FilterChip({
    required this.label,
    required this.isActive,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: isActive ? color.withAlpha(51) : AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(
            color: isActive ? color : AppTheme.surfaceVariantDark,
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          style: GoogleFonts.outfit(
            color: isActive ? color : AppTheme.textSecondary,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

// ── Log Card ──────────────────────────────────────────────────────────────────

class _LogCard extends StatelessWidget {
  final AppLog log;
  const _LogCard({required this.log});

  Color get _levelColor {
    switch (log.level) {
      case LogLevel.critical:
        return AppTheme.error;
      case LogLevel.error:
        return const Color(0xFFFF6B6B);
      case LogLevel.warning:
        return AppTheme.warning;
      case LogLevel.info:
        return AppTheme.info;
      case LogLevel.debug:
        return AppTheme.textMuted;
    }
  }

  Color get _categoryColor {
    switch (log.category) {
      case LogCategory.crash:
        return AppTheme.error;
      case LogCategory.apiError:
        return AppTheme.warning;
      case LogCategory.userFailure:
        return AppTheme.info;
      case LogCategory.network:
        return AppTheme.primaryLight;
      case LogCategory.auth:
        return AppTheme.crystalAccent;
      case LogCategory.unknown:
        return AppTheme.textMuted;
    }
  }

  String get _categoryLabel {
    switch (log.category) {
      case LogCategory.crash:
        return 'CRASH';
      case LogCategory.apiError:
        return 'API';
      case LogCategory.userFailure:
        return 'USER';
      case LogCategory.network:
        return 'NET';
      case LogCategory.auth:
        return 'AUTH';
      case LogCategory.unknown:
        return '???';
    }
  }

  IconData get _categoryIcon {
    switch (log.category) {
      case LogCategory.crash:
        return Icons.bug_report_rounded;
      case LogCategory.apiError:
        return Icons.cloud_off_rounded;
      case LogCategory.userFailure:
        return Icons.person_off_rounded;
      case LogCategory.network:
        return Icons.wifi_off_rounded;
      case LogCategory.auth:
        return Icons.lock_outline_rounded;
      case LogCategory.unknown:
        return Icons.help_outline_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('MMM d, HH:mm:ss');
    return Container(
      margin: const EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _levelColor.withAlpha(51), width: 1),
      ),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        leading: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: _categoryColor.withAlpha(30),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(_categoryIcon, color: _categoryColor, size: 18),
        ),
        title: Text(
          log.message,
          style: GoogleFonts.outfit(
            color: AppTheme.textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _categoryColor.withAlpha(30),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  _categoryLabel,
                  style: GoogleFonts.outfit(
                    color: _categoryColor,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _levelColor.withAlpha(25),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  log.level.value.toUpperCase(),
                  style: GoogleFonts.outfit(
                    color: _levelColor,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                fmt.format(log.createdAt.toLocal()),
                style: GoogleFonts.outfit(
                  color: AppTheme.textMuted,
                  fontSize: 10,
                ),
              ),
            ],
          ),
        ),
        children: [
          if (log.details != null && log.details!.isNotEmpty) ...[
            const Divider(color: AppTheme.surfaceVariantDark, height: 16),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Details',
                style: GoogleFonts.outfit(
                  color: AppTheme.textSecondary,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.backgroundDark,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                log.details!.entries
                    .map((e) => '${e.key}: ${e.value}')
                    .join('\n'),
                style: GoogleFonts.sourceCodePro(
                  color: AppTheme.textSecondary,
                  fontSize: 11,
                ),
              ),
            ),
          ],
          if (log.stackTrace != null) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Stack Trace',
                style: GoogleFonts.outfit(
                  color: AppTheme.textSecondary,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.backgroundDark,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                log.stackTrace!.length > 500
                    ? '${log.stackTrace!.substring(0, 500)}…'
                    : log.stackTrace!,
                style: GoogleFonts.sourceCodePro(
                  color: AppTheme.textMuted,
                  fontSize: 10,
                ),
              ),
            ),
          ],
          if (log.platform != null) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(
                  Icons.devices_rounded,
                  color: AppTheme.textMuted,
                  size: 14,
                ),
                const SizedBox(width: 4),
                Text(
                  'Platform: ${log.platform}',
                  style: GoogleFonts.outfit(
                    color: AppTheme.textMuted,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

// ── Empty / Error Views ───────────────────────────────────────────────────────

class _EmptyView extends StatelessWidget {
  final bool hasFilters;
  const _EmptyView({required this.hasFilters});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.check_circle_outline_rounded,
            color: AppTheme.success,
            size: 56,
          ),
          const SizedBox(height: 16),
          Text(
            hasFilters ? 'No logs match the filter' : 'No logs yet',
            style: GoogleFonts.outfit(
              color: AppTheme.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            hasFilters
                ? 'Try clearing the filter'
                : 'Errors and crashes will appear here',
            style: GoogleFonts.outfit(color: AppTheme.textMuted, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.error_outline_rounded,
            color: AppTheme.error,
            size: 48,
          ),
          const SizedBox(height: 12),
          Text(
            message,
            style: GoogleFonts.outfit(
              color: AppTheme.textSecondary,
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded, size: 18),
            label: const Text('Retry'),
          ),
        ],
      ),
    );
  }
}
