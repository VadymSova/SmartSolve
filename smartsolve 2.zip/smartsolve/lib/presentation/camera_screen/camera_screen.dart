import 'dart:convert';
import 'dart:io' if (dart.library.io) 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../theme/app_theme.dart';
import '../../services/logging_service.dart';
import '../../services/analytics_service.dart';

// ── State ─────────────────────────────────────────────────────────────────────

enum CameraScreenStatus { idle, capturing, solving, solved, error }

class CameraScreenState {
  final CameraScreenStatus status;
  final XFile? capturedImage;
  final String solution;
  final String? errorMessage;

  const CameraScreenState({
    this.status = CameraScreenStatus.idle,
    this.capturedImage,
    this.solution = '',
    this.errorMessage,
  });

  CameraScreenState copyWith({
    CameraScreenStatus? status,
    XFile? capturedImage,
    String? solution,
    String? errorMessage,
    bool clearImage = false,
    bool clearError = false,
  }) {
    return CameraScreenState(
      status: status ?? this.status,
      capturedImage: clearImage ? null : (capturedImage ?? this.capturedImage),
      solution: solution ?? this.solution,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }
}

// ── Notifier ──────────────────────────────────────────────────────────────────

class CameraScreenNotifier extends StateNotifier<CameraScreenState> {
  CameraScreenNotifier() : super(const CameraScreenState());

  static const String _edgeFunctionName = 'solve-homework';

  Future<void> solveImage(XFile imageFile) async {
    state = state.copyWith(
      status: CameraScreenStatus.solving,
      capturedImage: imageFile,
      solution: '',
      clearError: true,
    );

    final solveStart = DateTime.now();
    await AnalyticsService.instance.trackSolveStarted(source: 'camera');

    try {
      final bytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(bytes);
      final mimeType = imageFile.mimeType ?? 'image/jpeg';
      final base64DataUri = 'data:$mimeType;base64,$base64Image';

      final supabase = Supabase.instance.client;

      final response = await supabase.functions
          .invoke(_edgeFunctionName, body: {'imageBase64': base64DataUri})
          .timeout(
            const Duration(seconds: 60),
            onTimeout: () => throw Exception(
              'Request timed out. Please check your connection and try again.',
            ),
          );

      if (response.status != 200) {
        final statusCode = response.status;
        String message;
        if (statusCode == 429) {
          message = 'Too many requests. Please wait a moment and try again.';
        } else if (statusCode >= 500) {
          message = 'Server error. Please try again in a moment.';
        } else {
          message =
              'Something went wrong (error $statusCode). Please try again.';
        }
        LoggingService.instance.logApiError(
          'solve-homework edge function error: $message',
          extra: {'status': statusCode, 'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackApiError(
          endpoint: _edgeFunctionName,
          statusCode: statusCode,
          message: message,
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'http_$statusCode',
        );
        throw Exception(message);
      }

      final data = response.data as Map<String, dynamic>;
      final solution = data['solution'] as String? ?? 'No solution returned.';

      final durationMs = DateTime.now().difference(solveStart).inMilliseconds;
      await AnalyticsService.instance.trackSolveCompleted(
        source: 'camera',
        durationMs: durationMs,
      );

      state = state.copyWith(
        status: CameraScreenStatus.solved,
        solution: solution,
      );
    } on FunctionException catch (e) {
      final raw = e.details?.toString() ?? '';
      String message;
      if (raw.toLowerCase().contains('timeout') ||
          raw.toLowerCase().contains('timed out')) {
        message =
            'Request timed out. Please check your connection and try again.';
        LoggingService.instance.logNetworkError(
          'solve-homework timeout',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackNetworkError(
          message: 'solve timeout',
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'timeout',
        );
      } else if (raw.toLowerCase().contains('rate limit') ||
          raw.toLowerCase().contains('429')) {
        message = 'Too many requests. Please wait a moment and try again.';
        LoggingService.instance.logApiError(
          'solve-homework rate limited',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackApiError(
          endpoint: _edgeFunctionName,
          statusCode: 429,
          message: 'rate_limited',
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'rate_limit',
        );
      } else if (raw.isNotEmpty) {
        message = 'AI service error. Please try again.';
        LoggingService.instance.logApiError(
          'solve-homework FunctionException: $raw',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackApiError(
          endpoint: _edgeFunctionName,
          message: raw,
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'function_exception',
        );
      } else {
        message = 'Failed to solve homework. Please try again.';
        LoggingService.instance.logApiError(
          'solve-homework unknown FunctionException',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'unknown',
        );
      }
      state = state.copyWith(
        status: CameraScreenStatus.error,
        errorMessage: message,
      );
    } catch (e) {
      final raw = e.toString();
      String message;
      if (raw.toLowerCase().contains('timeout') ||
          raw.toLowerCase().contains('timed out')) {
        message =
            'Request timed out. Please check your connection and try again.';
        LoggingService.instance.logNetworkError(
          'solve-homework timeout (catch)',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackNetworkError(
          message: 'solve timeout',
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'timeout',
        );
      } else if (raw.toLowerCase().contains('socket') ||
          raw.toLowerCase().contains('network') ||
          raw.toLowerCase().contains('connection')) {
        message =
            'No internet connection. Please check your network and try again.';
        LoggingService.instance.logNetworkError(
          'solve-homework network error',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackNetworkError(
          message: 'no internet',
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'network',
        );
      } else if (raw.contains('Exception: ')) {
        message = raw.replaceFirst('Exception: ', '');
        LoggingService.instance.logApiError(
          'solve-homework error: $message',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'exception',
        );
      } else {
        message = 'An unexpected error occurred. Please try again.';
        LoggingService.instance.logCrash(
          'solve-homework unexpected error',
          error: e,
          extra: {'function': _edgeFunctionName},
        );
        await AnalyticsService.instance.trackCrash(
          message: raw,
          screen: 'camera_screen',
        );
        await AnalyticsService.instance.trackSolveFailed(
          source: 'camera',
          reason: 'crash',
        );
      }
      state = state.copyWith(
        status: CameraScreenStatus.error,
        errorMessage: message,
      );
    }
  }

  void reset() {
    state = const CameraScreenState();
  }

  void setImage(XFile image) {
    state = state.copyWith(
      capturedImage: image,
      status: CameraScreenStatus.idle,
      solution: '',
      clearError: true,
    );
  }
}

final cameraScreenProvider =
    StateNotifierProvider.autoDispose<CameraScreenNotifier, CameraScreenState>(
      (ref) => CameraScreenNotifier(),
    );

// ── Screen ────────────────────────────────────────────────────────────────────

class CameraScreen extends ConsumerStatefulWidget {
  const CameraScreen({super.key});

  @override
  ConsumerState<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends ConsumerState<CameraScreen>
    with WidgetsBindingObserver {
  CameraController? _cameraController;
  List<CameraDescription> _cameras = [];
  bool _cameraInitialized = false;
  bool _cameraPermissionDenied = false;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initCamera();
    AnalyticsService.instance.trackCameraOpened();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      return;
    }
    if (state == AppLifecycleState.inactive) {
      _cameraController?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      _initCamera();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _initCamera() async {
    if (kIsWeb) {
      setState(() => _cameraInitialized = false);
      return;
    }

    try {
      final status = await Permission.camera.request();
      if (!status.isGranted) {
        setState(() => _cameraPermissionDenied = true);
        LoggingService.instance.logUserFailure(
          'Camera permission denied',
          extra: {'platform': defaultTargetPlatform.name},
        );
        return;
      }

      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        setState(() => _cameraInitialized = false);
        LoggingService.instance.logUserFailure(
          'No cameras available on device',
        );
        return;
      }

      final backCamera = _cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => _cameras.first,
      );

      final controller = CameraController(
        backCamera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await controller.initialize();
      try {
        await controller.setFocusMode(FocusMode.auto);
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _cameraController = controller;
        _cameraInitialized = true;
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _cameraInitialized = false;
        });
        LoggingService.instance.logUserFailure(
          'Camera initialization failed',
          error: e,
          extra: {'platform': defaultTargetPlatform.name},
        );
        Fluttertoast.showToast(
          msg: 'Could not start camera. Try using the gallery instead.',
          backgroundColor: AppTheme.error,
          toastLength: Toast.LENGTH_LONG,
        );
      }
    }
  }

  Future<void> _capturePhoto() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      Fluttertoast.showToast(
        msg: 'Camera is not ready. Please try again.',
        backgroundColor: AppTheme.error,
      );
      return;
    }
    try {
      final photo = await _cameraController!.takePicture();
      await AnalyticsService.instance.trackCameraCaptured();
      ref.read(cameraScreenProvider.notifier).setImage(photo);
    } catch (e) {
      LoggingService.instance.logUserFailure('Photo capture failed', error: e);
      Fluttertoast.showToast(
        msg: 'Failed to capture photo. Please try again.',
        backgroundColor: AppTheme.error,
        toastLength: Toast.LENGTH_LONG,
      );
    }
  }

  Future<void> _pickFromGallery() async {
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
      );
      if (picked != null) {
        await AnalyticsService.instance.trackGalleryPicked();
        ref.read(cameraScreenProvider.notifier).setImage(picked);
      }
    } catch (e) {
      LoggingService.instance.logUserFailure('Gallery picker failed', error: e);
      Fluttertoast.showToast(
        msg: 'Could not open gallery. Please try again.',
        backgroundColor: AppTheme.error,
        toastLength: Toast.LENGTH_LONG,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenState = ref.watch(cameraScreenProvider);

    ref.listen<CameraScreenState>(cameraScreenProvider, (prev, next) {
      if (next.status == CameraScreenStatus.error &&
          next.errorMessage != null) {
        Fluttertoast.showToast(
          msg: next.errorMessage!,
          backgroundColor: AppTheme.error,
        );
      }
    });

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        backgroundColor: AppTheme.backgroundDark,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: AppTheme.textPrimary,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Scan Homework',
          style: GoogleFonts.outfit(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
        actions: [
          if (screenState.capturedImage != null &&
              screenState.status != CameraScreenStatus.solving)
            TextButton.icon(
              onPressed: () => ref.read(cameraScreenProvider.notifier).reset(),
              icon: const Icon(
                Icons.refresh_rounded,
                color: AppTheme.primaryLight,
                size: 18,
              ),
              label: Text(
                'Retake',
                style: GoogleFonts.outfit(
                  color: AppTheme.primaryLight,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ),
        ],
      ),
      body: screenState.capturedImage != null
          ? _buildReviewAndSolveView(screenState)
          : _buildCameraView(),
    );
  }

  // ── Camera View ─────────────────────────────────────────────────────────────

  Widget _buildCameraView() {
    return Column(
      children: [
        Expanded(child: _buildCameraPreview()),
        _buildCameraControls(),
      ],
    );
  }

  Widget _buildCameraPreview() {
    if (kIsWeb) {
      return _buildWebCameraPlaceholder();
    }
    if (_cameraPermissionDenied) {
      return _buildPermissionDeniedView();
    }
    if (!_cameraInitialized || _cameraController == null) {
      return const Center(
        child: CircularProgressIndicator(color: AppTheme.primary),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.vertical(
            bottom: Radius.circular(24),
          ),
          child: CameraPreview(_cameraController!),
        ),
        // Scan frame overlay
        Center(
          child: Container(
            width: 280,
            height: 280,
            decoration: BoxDecoration(
              border: Border.all(color: AppTheme.primaryLight, width: 2.5),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Stack(
              children: [
                _cornerIndicator(Alignment.topLeft),
                _cornerIndicator(Alignment.topRight),
                _cornerIndicator(Alignment.bottomLeft),
                _cornerIndicator(Alignment.bottomRight),
              ],
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.black.withAlpha(153),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                'Position homework inside the frame',
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _cornerIndicator(Alignment alignment) {
    final isTop =
        alignment == Alignment.topLeft || alignment == Alignment.topRight;
    final isLeft =
        alignment == Alignment.topLeft || alignment == Alignment.bottomLeft;
    return Align(
      alignment: alignment,
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          border: Border(
            top: isTop
                ? const BorderSide(color: AppTheme.crystalAccent, width: 3)
                : BorderSide.none,
            bottom: !isTop
                ? const BorderSide(color: AppTheme.crystalAccent, width: 3)
                : BorderSide.none,
            left: isLeft
                ? const BorderSide(color: AppTheme.crystalAccent, width: 3)
                : BorderSide.none,
            right: !isLeft
                ? const BorderSide(color: AppTheme.crystalAccent, width: 3)
                : BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildWebCameraPlaceholder() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.primary.withAlpha(77), width: 1.5),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.camera_alt_rounded,
            color: AppTheme.primary.withAlpha(153),
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'Camera preview not available on web',
            style: GoogleFonts.outfit(
              color: AppTheme.textSecondary,
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Use "Pick from Gallery" to upload a homework photo',
            style: GoogleFonts.outfit(color: AppTheme.textMuted, fontSize: 13),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildPermissionDeniedView() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.no_photography_rounded,
            color: AppTheme.error,
            size: 64,
          ),
          const SizedBox(height: 16),
          Text(
            'Camera Permission Denied',
            style: GoogleFonts.outfit(
              color: AppTheme.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Please enable camera access in your device settings.',
            style: GoogleFonts.outfit(
              color: AppTheme.textSecondary,
              fontSize: 13,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: openAppSettings,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'Open Settings',
              style: GoogleFonts.outfit(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCameraControls() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Gallery button
          _CircleButton(
            icon: Icons.photo_library_rounded,
            label: 'Gallery',
            onTap: _pickFromGallery,
            color: AppTheme.surfaceVariantDark,
            iconColor: AppTheme.textPrimary,
          ),
          // Capture button
          if (!kIsWeb)
            GestureDetector(
              onTap: _capturePhoto,
              child: Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppTheme.primaryGradient,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.primary.withAlpha(102),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.camera_alt_rounded,
                  color: Colors.white,
                  size: 32,
                ),
              ),
            )
          else
            const SizedBox(width: 72),
          // Flip camera (mobile only)
          _CircleButton(
            icon: Icons.flip_camera_ios_rounded,
            label: 'Flip',
            onTap: kIsWeb ? null : _flipCamera,
            color: AppTheme.surfaceVariantDark,
            iconColor: kIsWeb ? AppTheme.textMuted : AppTheme.textPrimary,
          ),
        ],
      ),
    );
  }

  Future<void> _flipCamera() async {
    if (_cameras.length < 2) return;
    final currentDirection = _cameraController?.description.lensDirection;
    final newCamera = _cameras.firstWhere(
      (c) => c.lensDirection != currentDirection,
      orElse: () => _cameras.first,
    );
    await _cameraController?.dispose();
    final controller = CameraController(
      newCamera,
      ResolutionPreset.high,
      enableAudio: false,
    );
    await controller.initialize();
    if (!mounted) return;
    setState(() => _cameraController = controller);
  }

  // ── Review & Solve View ─────────────────────────────────────────────────────

  Widget _buildReviewAndSolveView(CameraScreenState screenState) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Captured image preview
          _buildImagePreview(screenState.capturedImage!),
          const SizedBox(height: 16),

          // Error card with retry button
          if (screenState.status == CameraScreenStatus.error &&
              screenState.errorMessage != null)
            _buildErrorCard(
              screenState.errorMessage!,
              screenState.capturedImage!,
            ),

          // Solve button (idle state only)
          if (screenState.status == CameraScreenStatus.idle)
            _buildSolveButton(screenState.capturedImage!),

          if (screenState.status == CameraScreenStatus.solving)
            _buildSolvingIndicator(),

          if (screenState.status == CameraScreenStatus.solved &&
              screenState.solution.isNotEmpty)
            _buildSolutionCard(screenState.solution),
        ],
      ),
    );
  }

  Widget _buildImagePreview(XFile image) {
    return Container(
      height: 260,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.primary.withAlpha(77), width: 1.5),
      ),
      clipBehavior: Clip.antiAlias,
      child: kIsWeb
          ? Image.network(image.path, fit: BoxFit.cover)
          : Image.file(File(image.path), fit: BoxFit.cover),
    );
  }

  Widget _buildSolveButton(XFile image) {
    return Container(
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withAlpha(77),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ElevatedButton.icon(
        onPressed: () =>
            ref.read(cameraScreenProvider.notifier).solveImage(image),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        icon: const Icon(
          Icons.auto_awesome_rounded,
          color: Colors.white,
          size: 22,
        ),
        label: Text(
          'Solve with AI',
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 16,
          ),
        ),
      ),
    );
  }

  Widget _buildSolvingIndicator() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.primary.withAlpha(51), width: 1),
      ),
      child: Column(
        children: [
          const SizedBox(
            width: 40,
            height: 40,
            child: CircularProgressIndicator(
              color: AppTheme.primaryLight,
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Analyzing your homework…',
            style: GoogleFonts.outfit(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'OpenAI is reading and solving the problem',
            style: GoogleFonts.outfit(
              color: AppTheme.textSecondary,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSolutionCard(String solution) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.primary.withAlpha(77), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withAlpha(20),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGradient,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.auto_awesome_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                'AI Solution',
                style: GoogleFonts.outfit(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.success.withAlpha(26),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: AppTheme.success.withAlpha(77),
                    width: 1,
                  ),
                ),
                child: Text(
                  'Solved',
                  style: GoogleFonts.outfit(
                    color: AppTheme.success,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: Color(0xFF2E2B42), height: 1),
          const SizedBox(height: 16),
          SelectableText(
            solution,
            style: GoogleFonts.outfit(
              color: AppTheme.textPrimary,
              fontSize: 14,
              height: 1.7,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () =>
                      ref.read(cameraScreenProvider.notifier).reset(),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(
                      color: Color(0xFF4A4660),
                      width: 1.5,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  icon: const Icon(
                    Icons.camera_alt_rounded,
                    size: 18,
                    color: AppTheme.textSecondary,
                  ),
                  label: Text(
                    'New Photo',
                    style: GoogleFonts.outfit(
                      color: AppTheme.textSecondary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildErrorCard(String errorMessage, XFile image) {
    final isTimeout =
        errorMessage.toLowerCase().contains('timed out') ||
        errorMessage.toLowerCase().contains('timeout') ||
        errorMessage.toLowerCase().contains('connection') ||
        errorMessage.toLowerCase().contains('network') ||
        errorMessage.toLowerCase().contains('internet');

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.error.withAlpha(20),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.error.withAlpha(77), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: AppTheme.error.withAlpha(30),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.error_outline_rounded,
                  color: AppTheme.error,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  isTimeout ? 'Connection Problem' : 'Something Went Wrong',
                  style: GoogleFonts.outfit(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            errorMessage,
            style: GoogleFonts.outfit(
              color: AppTheme.textSecondary,
              fontSize: 13,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () =>
                      ref.read(cameraScreenProvider.notifier).solveImage(image),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.error,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: Text(
                    isTimeout ? 'Retry' : 'Try Again',
                    style: GoogleFonts.outfit(
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Helper Widget ─────────────────────────────────────────────────────────────

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color color;
  final Color iconColor;

  const _CircleButton({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.color,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            child: Icon(icon, color: iconColor, size: 24),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: GoogleFonts.outfit(
              color: AppTheme.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
