import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class AuthSocialButtonsWidget extends StatelessWidget {
  final String selectedLanguage;
  final VoidCallback onGoogleTap;
  final VoidCallback onAppleTap;

  const AuthSocialButtonsWidget({
    super.key,
    required this.selectedLanguage,
    required this.onGoogleTap,
    required this.onAppleTap,
  });

  @override
  Widget build(BuildContext context) {
    final googleLabel = selectedLanguage == 'ru'
        ? 'Войти через Google'
        : 'Continue with Google';
    final appleLabel = selectedLanguage == 'ru'
        ? 'Войти через Apple'
        : 'Continue with Apple';

    return Column(
      children: [
        _SocialButton(
          label: googleLabel,
          icon: Icons.g_mobiledata_rounded,
          iconColor: const Color(0xFF4285F4),
          onTap: onGoogleTap,
        ),
        const SizedBox(height: 12),
        _SocialButton(
          label: appleLabel,
          icon: Icons.apple_rounded,
          iconColor: AppTheme.textPrimary,
          onTap: onAppleTap,
        ),
      ],
    );
  }
}

class _SocialButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color iconColor;
  final VoidCallback onTap;

  const _SocialButton({
    required this.label,
    required this.icon,
    required this.iconColor,
    required this.onTap,
  });

  @override
  State<_SocialButton> createState() => _SocialButtonState();
}

class _SocialButtonState extends State<_SocialButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
      lowerBound: 0.96,
      upperBound: 1.0,
      value: 1.0,
    );
    _scale = _ctrl;
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.reverse(),
      onTapUp: (_) {
        _ctrl.forward();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.forward(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          height: 52,
          decoration: BoxDecoration(
            color: AppTheme.surfaceVariantDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: AppTheme.primary.withAlpha(51),
              width: 1.5,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(widget.icon, size: 22, color: widget.iconColor),
              const SizedBox(width: 10),
              Text(
                widget.label,
                style: GoogleFonts.outfit(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
