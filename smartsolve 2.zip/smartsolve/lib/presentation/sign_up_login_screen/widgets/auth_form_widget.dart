import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../theme/app_theme.dart';
import '../../../services/analytics_service.dart';

class AuthFormWidget extends StatefulWidget {
  final bool isLogin;
  final String selectedLanguage;
  final VoidCallback onSuccess;

  const AuthFormWidget({
    super.key,
    required this.isLogin,
    required this.selectedLanguage,
    required this.onSuccess,
  });

  @override
  State<AuthFormWidget> createState() => _AuthFormWidgetState();
}

class _AuthFormWidgetState extends State<AuthFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscurePassword = true;
  bool _rememberMe = false;
  bool _isSubmitting = false;
  String? _errorMessage;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });

    final email = _emailCtrl.text.trim();
    final password = _passwordCtrl.text;

    try {
      if (widget.isLogin) {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
        await AnalyticsService.instance.trackSignIn(method: 'email');
      } else {
        final name = _nameCtrl.text.trim();
        await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
          data: {'full_name': name},
        );
        await AnalyticsService.instance.trackSignUp(method: 'email');
      }
      await AnalyticsService.instance.startSession();
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      widget.onSuccess();
    } on AuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _isSubmitting = false;
        _errorMessage = _mapAuthError(e.message);
      });
      await AnalyticsService.instance.trackAuthError(
        reason: e.message,
        method: 'email',
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSubmitting = false;
        _errorMessage = widget.selectedLanguage == 'ru'
            ? 'Произошла ошибка. Попробуйте снова.'
            : 'Something went wrong. Please try again.';
      });
    }
  }

  String _mapAuthError(String message) {
    final isRu = widget.selectedLanguage == 'ru';
    final lower = message.toLowerCase();
    if (lower.contains('invalid login') ||
        lower.contains('invalid credentials')) {
      return isRu ? 'Неверный email или пароль' : 'Invalid email or password';
    }
    if (lower.contains('email not confirmed')) {
      return isRu
          ? 'Подтвердите email перед входом'
          : 'Please confirm your email before signing in';
    }
    if (lower.contains('user already registered') ||
        lower.contains('already registered')) {
      return isRu
          ? 'Этот email уже зарегистрирован. Войдите.'
          : 'This email is already registered. Please sign in.';
    }
    if (lower.contains('password should be at least')) {
      return isRu
          ? 'Пароль должен быть не менее 6 символов'
          : 'Password must be at least 6 characters';
    }
    return isRu ? message : message;
  }

  @override
  Widget build(BuildContext context) {
    final isRu = widget.selectedLanguage == 'ru';

    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (!widget.isLogin) ...[
            _buildField(
              controller: _nameCtrl,
              label: isRu ? 'Имя' : 'Full Name',
              hint: isRu ? 'Введите ваше имя' : 'Enter your name',
              icon: Icons.person_rounded,
              validator: (v) {
                if (v == null || v.trim().isEmpty) {
                  return isRu ? 'Введите имя' : 'Name is required';
                }
                return null;
              },
            ),
            const SizedBox(height: 14),
          ],
          _buildField(
            controller: _emailCtrl,
            label: isRu ? 'Email' : 'Email',
            hint: isRu ? 'Введите email' : 'Enter your email',
            icon: Icons.email_rounded,
            keyboardType: TextInputType.emailAddress,
            validator: (v) {
              if (v == null || v.trim().isEmpty) {
                return isRu ? 'Введите email' : 'Email is required';
              }
              if (!v.contains('@') || !v.contains('.')) {
                return isRu
                    ? 'Введите корректный email'
                    : 'Enter a valid email';
              }
              return null;
            },
          ),
          const SizedBox(height: 14),
          _buildPasswordField(isRu: isRu),
          if (widget.isLogin) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                GestureDetector(
                  onTap: () => setState(() => _rememberMe = !_rememberMe),
                  child: Row(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          color: _rememberMe
                              ? AppTheme.primary
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: _rememberMe
                                ? AppTheme.primary
                                : AppTheme.textMuted,
                            width: 1.5,
                          ),
                        ),
                        child: _rememberMe
                            ? const Icon(
                                Icons.check_rounded,
                                size: 13,
                                color: Colors.white,
                              )
                            : null,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isRu ? 'Запомнить меня' : 'Remember me',
                        style: GoogleFonts.outfit(
                          fontSize: 13,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _showForgotPassword(context, isRu),
                  child: Text(
                    isRu ? 'Забыли пароль?' : 'Forgot password?',
                    style: GoogleFonts.outfit(
                      fontSize: 13,
                      color: AppTheme.primaryLight,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ],
          if (_errorMessage != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: AppTheme.error.withAlpha(31),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.error.withAlpha(77),
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.error_rounded,
                    size: 16,
                    color: AppTheme.error,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _errorMessage!,
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        color: AppTheme.error,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 20),
          // Submit button
          SizedBox(
            height: 52,
            child: ElevatedButton(
              onPressed: _isSubmitting ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                disabledBackgroundColor: AppTheme.primary.withAlpha(128),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
              child: _isSubmitting
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : Text(
                      widget.isLogin
                          ? (isRu ? 'Войти' : 'Sign In')
                          : (isRu ? 'Создать аккаунт' : 'Create Account'),
                      style: GoogleFonts.outfit(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
            ),
          ),
          if (!widget.isLogin) ...[
            const SizedBox(height: 12),
            Text(
              isRu
                  ? 'Регистрируясь, вы соглашаетесь с Условиями использования и Политикой конфиденциальности'
                  : 'By signing up, you agree to our Terms of Service and Privacy Policy',
              style: GoogleFonts.outfit(
                fontSize: 11,
                color: AppTheme.textMuted,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }

  void _showForgotPassword(BuildContext context, bool isRu) {
    final emailCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          isRu ? 'Сброс пароля' : 'Reset Password',
          style: GoogleFonts.outfit(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isRu
                  ? 'Введите email для получения ссылки сброса пароля'
                  : 'Enter your email to receive a password reset link',
              style: GoogleFonts.outfit(
                fontSize: 13,
                color: AppTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: emailCtrl,
              keyboardType: TextInputType.emailAddress,
              style: GoogleFonts.outfit(color: AppTheme.textPrimary),
              decoration: InputDecoration(
                hintText: isRu ? 'Ваш email' : 'Your email',
                hintStyle: GoogleFonts.outfit(color: AppTheme.textMuted),
                filled: true,
                fillColor: AppTheme.surfaceVariantDark,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(
              isRu ? 'Отмена' : 'Cancel',
              style: GoogleFonts.outfit(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary),
            onPressed: () async {
              final email = emailCtrl.text.trim();
              if (email.isEmpty) return;
              Navigator.pop(ctx);
              try {
                await Supabase.instance.client.auth.resetPasswordForEmail(
                  email,
                );
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        isRu
                            ? 'Ссылка отправлена на $email'
                            : 'Reset link sent to $email',
                        style: GoogleFonts.outfit(color: Colors.white),
                      ),
                      backgroundColor: AppTheme.surfaceVariantDark,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  );
                }
              } catch (_) {}
            },
            child: Text(
              isRu ? 'Отправить' : 'Send',
              style: GoogleFonts.outfit(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      style: GoogleFonts.outfit(fontSize: 15, color: AppTheme.textPrimary),
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, size: 20, color: AppTheme.textSecondary),
        filled: true,
        fillColor: AppTheme.surfaceVariantDark,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF4A4660), width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF4A4660), width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.primary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.error, width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.error, width: 2),
        ),
        labelStyle: GoogleFonts.outfit(
          fontSize: 14,
          color: AppTheme.textSecondary,
        ),
        hintStyle: GoogleFonts.outfit(fontSize: 14, color: AppTheme.textMuted),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 16,
        ),
      ),
    );
  }

  Widget _buildPasswordField({required bool isRu}) {
    return TextFormField(
      controller: _passwordCtrl,
      obscureText: _obscurePassword,
      style: GoogleFonts.outfit(fontSize: 15, color: AppTheme.textPrimary),
      validator: (v) {
        if (v == null || v.isEmpty) {
          return isRu ? 'Введите пароль' : 'Password is required';
        }
        if (!widget.isLogin && v.length < 6) {
          return isRu ? 'Минимум 6 символов' : 'Minimum 6 characters';
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: isRu ? 'Пароль' : 'Password',
        hintText: isRu ? 'Введите пароль' : 'Enter your password',
        prefixIcon: const Icon(
          Icons.lock_rounded,
          size: 20,
          color: AppTheme.textSecondary,
        ),
        suffixIcon: GestureDetector(
          onTap: () => setState(() => _obscurePassword = !_obscurePassword),
          child: Icon(
            _obscurePassword
                ? Icons.visibility_off_rounded
                : Icons.visibility_rounded,
            size: 20,
            color: AppTheme.textSecondary,
          ),
        ),
        filled: true,
        fillColor: AppTheme.surfaceVariantDark,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF4A4660), width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: Color(0xFF4A4660), width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.primary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.error, width: 1.5),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppTheme.error, width: 2),
        ),
        labelStyle: GoogleFonts.outfit(
          fontSize: 14,
          color: AppTheme.textSecondary,
        ),
        hintStyle: GoogleFonts.outfit(fontSize: 14, color: AppTheme.textMuted),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 16,
        ),
      ),
    );
  }
}
