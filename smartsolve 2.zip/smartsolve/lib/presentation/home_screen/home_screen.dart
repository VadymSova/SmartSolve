import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/app_export.dart';
import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_navigation.dart';
import './widgets/ai_response_card_widget.dart';
import './widgets/avatar_greeting_widget.dart';
import './widgets/category_row_widget.dart';
import './widgets/crystal_balance_widget.dart';
import './widgets/problem_input_widget.dart';
import './widgets/recent_solutions_widget.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with TickerProviderStateMixin {
  int _navIndex = 0;
  bool _navVisible = true;
  late ScrollController _scrollController;
  late AnimationController _fabController;
  late Animation<double> _fabScale;

  int _crystalBalance = 240;
  int _dailyUsed = 2;
  static const int _dailyLimit = 5;
  String? _currentQuestion;
  final String _selectedLanguage = 'en';

  // Local AI state (bypasses AWS Lambda, calls Supabase Edge Function directly)
  bool _isLoading = false;
  String _aiResponse = '';
  String? _aiError;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);

    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
      value: 1.0,
    );
    _fabScale = CurvedAnimation(
      parent: _fabController,
      curve: Curves.easeOutCubic,
    );
  }

  void _onScroll() {
    final direction = _scrollController.position.userScrollDirection;
    if (direction == ScrollDirection.reverse && _navVisible) {
      setState(() => _navVisible = false);
      _fabController.reverse();
    } else if (direction == ScrollDirection.forward && !_navVisible) {
      setState(() => _navVisible = true);
      _fabController.forward();
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _fabController.dispose();
    super.dispose();
  }

  void _onSolveProblem(String problem) async {
    if (_dailyUsed >= _dailyLimit && _crystalBalance < 10) {
      _showLowCrystalsDialog();
      return;
    }

    setState(() {
      _currentQuestion = problem;
      _isLoading = true;
      _aiResponse = '';
      _aiError = null;
      if (_dailyUsed > _dailyLimit) {
        _crystalBalance = (_crystalBalance - 10).clamp(0, 9999);
      }
      _dailyUsed = (_dailyUsed + 1).clamp(0, 99);
    });

    try {
      // Call Supabase Edge Function directly — it reads OPENAI_API_KEY from secrets
      final response = await Supabase.instance.client.functions.invoke(
        'solve-homework',
        body: {'question': problem},
      );

      if (response.status != 200) {
        final errMsg =
            response.data?['error'] as String? ??
            'AI service error. Please try again.';
        setState(() {
          _isLoading = false;
          _aiError = errMsg;
        });
        Fluttertoast.showToast(msg: errMsg, backgroundColor: Colors.red);
        return;
      }

      final solution = response.data?['solution'] as String? ?? '';
      setState(() {
        _isLoading = false;
        _aiResponse = solution;
      });
    } catch (e) {
      final msg = 'Something went wrong. Please try again.';
      setState(() {
        _isLoading = false;
        _aiError = msg;
      });
      Fluttertoast.showToast(msg: msg, backgroundColor: Colors.red);
    }
  }

  void _showLowCrystalsDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(
              Icons.diamond_rounded,
              color: AppTheme.crystalAccent,
              size: 22,
            ),
            const SizedBox(width: 8),
            Text(
              'Out of Crystals',
              style: GoogleFonts.outfit(
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(
          'You\'ve used your free daily solutions. Buy crystals to keep solving problems.',
          style: GoogleFonts.outfit(
            color: AppTheme.textSecondary,
            fontSize: 14,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Later',
              style: GoogleFonts.outfit(color: AppTheme.textMuted),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, AppRoutes.settingsScreen);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.crystalAccent,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              'Buy Crystals',
              style: GoogleFonts.outfit(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  void _openCamera() {
    Navigator.pushNamed(context, AppRoutes.cameraScreen);
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      extendBody: true,
      body: SafeArea(
        bottom: false,
        child: isTablet ? _buildTabletLayout() : _buildPhoneLayout(),
      ),
      floatingActionButton: ScaleTransition(
        scale: _fabScale,
        child: FloatingActionButton.extended(
          onPressed: _openCamera,
          backgroundColor: AppTheme.crystalAccent,
          foregroundColor: Colors.black,
          elevation: 0,
          icon: const Icon(Icons.camera_alt_rounded, size: 22),
          label: Text(
            'Open Camera',
            style: GoogleFonts.outfit(
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(999),
          ),
        ),
      ),
      bottomNavigationBar: AnimatedSlide(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        offset: _navVisible ? Offset.zero : const Offset(0, 1.5),
        child: AppNavigation(
          currentIndex: _navIndex,
          onTap: (i) {
            setState(() => _navIndex = i);
            if (i == 3) {
              Navigator.pushNamed(context, AppRoutes.settingsScreen);
            }
          },
        ),
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return CustomScrollView(
      controller: _scrollController,
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AvatarGreetingWidget(
                  crystalBalance: _crystalBalance,
                  onSettingsTap: () =>
                      Navigator.pushNamed(context, AppRoutes.settingsScreen),
                ),
                const SizedBox(height: 20),
                CrystalBalanceWidget(
                  balance: _crystalBalance,
                  dailyUsed: _dailyUsed,
                  dailyLimit: _dailyLimit,
                  onBuyTap: () =>
                      Navigator.pushNamed(context, AppRoutes.settingsScreen),
                ),
                const SizedBox(height: 20),
                CategoryRowWidget(onCategoryTap: (category) {}),
                const SizedBox(height: 20),
                ProblemInputWidget(
                  isLoading: _isLoading,
                  onSubmit: _onSolveProblem,
                  onCameraTap: _openCamera,
                  selectedLanguage: _selectedLanguage,
                ),
                if (_currentQuestion != null &&
                    (_isLoading || _aiResponse.isNotEmpty)) ...[
                  const SizedBox(height: 16),
                  AiResponseCardWidget(
                    question: _currentQuestion ?? '',
                    response: _aiResponse.isNotEmpty ? _aiResponse : null,
                    isLoading: _isLoading && _aiResponse.isEmpty,
                  ),
                ],
                const SizedBox(height: 24),
                Text(
                  'Recent Solutions',
                  style: GoogleFonts.outfit(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(
            child: RecentSolutionsWidget(
              crystalBalance: _crystalBalance,
              selectedLanguage: _selectedLanguage,
            ),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 160)),
      ],
    );
  }

  Widget _buildTabletLayout() {
    return Row(
      children: [
        Expanded(
          flex: 6,
          child: CustomScrollView(
            controller: _scrollController,
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AvatarGreetingWidget(
                        crystalBalance: _crystalBalance,
                        onSettingsTap: () => Navigator.pushNamed(
                          context,
                          AppRoutes.settingsScreen,
                        ),
                      ),
                      const SizedBox(height: 20),
                      CategoryRowWidget(onCategoryTap: (_) {}),
                      const SizedBox(height: 20),
                      Text(
                        'Recent Solutions',
                        style: GoogleFonts.outfit(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 12),
                      RecentSolutionsWidget(
                        crystalBalance: _crystalBalance,
                        selectedLanguage: _selectedLanguage,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(width: 1, color: AppTheme.surfaceVariantDark),
        Expanded(
          flex: 4,
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                CrystalBalanceWidget(
                  balance: _crystalBalance,
                  dailyUsed: _dailyUsed,
                  dailyLimit: _dailyLimit,
                  onBuyTap: () =>
                      Navigator.pushNamed(context, AppRoutes.settingsScreen),
                ),
                const SizedBox(height: 20),
                ProblemInputWidget(
                  isLoading: _isLoading,
                  onSubmit: _onSolveProblem,
                  onCameraTap: _openCamera,
                  selectedLanguage: _selectedLanguage,
                ),
                if (_currentQuestion != null &&
                    (_isLoading || _aiResponse.isNotEmpty)) ...[
                  const SizedBox(height: 16),
                  AiResponseCardWidget(
                    question: _currentQuestion ?? '',
                    response: _aiResponse.isNotEmpty ? _aiResponse : null,
                    isLoading: _isLoading && _aiResponse.isEmpty,
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }
}
