import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class ProblemInputWidget extends StatefulWidget {
  final bool isLoading;
  final ValueChanged<String> onSubmit;
  final VoidCallback onCameraTap;
  final String selectedLanguage;

  const ProblemInputWidget({
    super.key,
    required this.isLoading,
    required this.onSubmit,
    required this.onCameraTap,
    required this.selectedLanguage,
  });

  @override
  State<ProblemInputWidget> createState() => _ProblemInputWidgetState();
}

class _ProblemInputWidgetState extends State<ProblemInputWidget> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusNode.addListener(() {
      setState(() => _isFocused = _focusNode.hasFocus);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    widget.onSubmit(text);
    _controller.clear();
    _focusNode.unfocus();
  }

  @override
  Widget build(BuildContext context) {
    final hint = widget.selectedLanguage == 'ru'
        ? 'Введите задачу или вопрос...'
        : 'Type your problem or question...';

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _isFocused
              ? AppTheme.primary.withAlpha(153)
              : AppTheme.surfaceVariantDark,
          width: 1.5,
        ),
        boxShadow: _isFocused
            ? [
                BoxShadow(
                  color: AppTheme.primary.withAlpha(38),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ]
            : [],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    gradient: AppTheme.primaryGradient,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.auto_awesome_rounded,
                        size: 12,
                        color: Colors.white,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'AI Solver',
                        style: GoogleFonts.outfit(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                // Camera button
                GestureDetector(
                  onTap: widget.onCameraTap,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: AppTheme.crystalAccent.withAlpha(38),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: AppTheme.crystalAccent.withAlpha(77),
                        width: 1,
                      ),
                    ),
                    child: const Icon(
                      Icons.camera_alt_rounded,
                      size: 18,
                      color: AppTheme.crystalAccent,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Text input
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              maxLines: 4,
              minLines: 2,
              style: GoogleFonts.outfit(
                fontSize: 15,
                color: AppTheme.textPrimary,
                height: 1.5,
              ),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: GoogleFonts.outfit(
                  fontSize: 14,
                  color: AppTheme.textMuted,
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
                contentPadding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
              ),
              onSubmitted: (_) => _submit(),
            ),
          ),
          // Action row
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.diamond_rounded,
                      size: 13,
                      color: AppTheme.crystalAccent,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '10 crystals per solution',
                      style: GoogleFonts.outfit(
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: widget.isLoading ? null : _submit,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: widget.isLoading
                          ? LinearGradient(
                              colors: [
                                AppTheme.primary.withAlpha(128),
                                AppTheme.primary.withAlpha(77),
                              ],
                            )
                          : AppTheme.primaryGradient,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: widget.isLoading
                          ? []
                          : [
                              BoxShadow(
                                color: AppTheme.primary.withAlpha(102),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                    ),
                    child: widget.isLoading
                        ? const Center(
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: Colors.white,
                              ),
                            ),
                          )
                        : const Icon(
                            Icons.send_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
