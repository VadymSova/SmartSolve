import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class CategoryRowWidget extends StatefulWidget {
  final ValueChanged<String> onCategoryTap;

  const CategoryRowWidget({super.key, required this.onCategoryTap});

  @override
  State<CategoryRowWidget> createState() => _CategoryRowWidgetState();
}

class _CategoryRowWidgetState extends State<CategoryRowWidget> {
  int _selectedIndex = 0;

  // TODO: Replace with Riverpod/Bloc for production category state
  final List<Map<String, dynamic>> _categories = [
    {
      'label': 'Math',
      'icon': Icons.calculate_rounded,
      'color': Color(0xFF7C3AED),
    },
    {
      'label': 'Science',
      'icon': Icons.science_rounded,
      'color': Color(0xFF10B981),
    },
    {
      'label': 'History',
      'icon': Icons.history_edu_rounded,
      'color': Color(0xFFF59E0B),
    },
    {
      'label': 'Language',
      'icon': Icons.menu_book_rounded,
      'color': Color(0xFF3B82F6),
    },
    {
      'label': 'Chemistry',
      'icon': Icons.biotech_rounded,
      'color': Color(0xFFEF4444),
    },
    {
      'label': 'Physics',
      'icon': Icons.bolt_rounded,
      'color': Color(0xFF8B5CF6),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Subjects',
          style: GoogleFonts.outfit(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 80,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: _categories.length,
            physics: const BouncingScrollPhysics(),
            itemBuilder: (context, index) {
              final cat = _categories[index];
              final isSelected = index == _selectedIndex;
              final color = cat['color'] as Color;

              return GestureDetector(
                onTap: () {
                  setState(() => _selectedIndex = index);
                  widget.onCategoryTap(cat['label'] as String);
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.only(right: 12),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        curve: Curves.easeOutCubic,
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: isSelected
                              ? color.withAlpha(64)
                              : AppTheme.surfaceVariantDark,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected
                                ? color.withAlpha(153)
                                : AppTheme.surfaceElevatedDark,
                            width: 1.5,
                          ),
                          boxShadow: isSelected
                              ? [
                                  BoxShadow(
                                    color: color.withAlpha(77),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ]
                              : [],
                        ),
                        child: Icon(
                          cat['icon'] as IconData,
                          size: 24,
                          color: isSelected ? color : AppTheme.textMuted,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        cat['label'] as String,
                        style: GoogleFonts.outfit(
                          fontSize: 11,
                          fontWeight: isSelected
                              ? FontWeight.w600
                              : FontWeight.w400,
                          color: isSelected ? color : AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
