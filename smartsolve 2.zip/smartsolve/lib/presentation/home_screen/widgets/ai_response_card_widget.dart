import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/loading_skeleton_widget.dart';

class AiResponseCardWidget extends StatefulWidget {
  final String question;
  final String? response;
  final bool isLoading;

  const AiResponseCardWidget({
    super.key,
    required this.question,
    this.response,
    required this.isLoading,
  });

  @override
  State<AiResponseCardWidget> createState() => _AiResponseCardWidgetState();
}

class _AiResponseCardWidgetState extends State<AiResponseCardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _entranceCtrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    )..forward();
    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(
          CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic),
        );
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Container(
          decoration: BoxDecoration(
            color: AppTheme.surfaceDark,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppTheme.primary.withAlpha(64),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.primary.withAlpha(26),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.primary.withAlpha(26),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: AppTheme.primary.withAlpha(51),
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.auto_awesome_rounded,
                      size: 16,
                      color: AppTheme.primaryLight,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'AI Solution',
                      style: GoogleFonts.outfit(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.primaryLight,
                      ),
                    ),
                    const Spacer(),
                    if (!widget.isLoading && widget.response != null)
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(
                            ClipboardData(text: widget.response!),
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Copied to clipboard',
                                style: GoogleFonts.outfit(color: Colors.white),
                              ),
                              backgroundColor: AppTheme.surfaceVariantDark,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              margin: const EdgeInsets.only(
                                bottom: 100,
                                left: 20,
                                right: 20,
                              ),
                            ),
                          );
                        },
                        child: const Icon(
                          Icons.copy_rounded,
                          size: 16,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                  ],
                ),
              ),
              // Question
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                child: Text(
                  widget.question,
                  style: GoogleFonts.outfit(
                    fontSize: 13,
                    color: AppTheme.textSecondary,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
              const Divider(height: 1, color: Color(0xFF2E2B42)),
              // Response
              Padding(
                padding: const EdgeInsets.all(16),
                child: widget.isLoading
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          LoadingSkeletonWidget(
                            width: double.infinity,
                            height: 14,
                            borderRadius: 6,
                          ),
                          const SizedBox(height: 8),
                          LoadingSkeletonWidget(
                            width: double.infinity,
                            height: 14,
                            borderRadius: 6,
                          ),
                          const SizedBox(height: 8),
                          LoadingSkeletonWidget(
                            width: 200,
                            height: 14,
                            borderRadius: 6,
                          ),
                        ],
                      )
                    : Text(
                        widget.response ?? '',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          color: AppTheme.textPrimary,
                          height: 1.6,
                        ),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
