import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../theme/app_theme.dart';

class AvatarGreetingWidget extends StatefulWidget {
  final int crystalBalance;
  final VoidCallback onSettingsTap;

  const AvatarGreetingWidget({
    super.key,
    required this.crystalBalance,
    required this.onSettingsTap,
  });

  @override
  State<AvatarGreetingWidget> createState() => _AvatarGreetingWidgetState();
}

class _AvatarGreetingWidgetState extends State<AvatarGreetingWidget> {
  String _displayName = '';

  @override
  void initState() {
    super.initState();
    _loadUserName();
  }

  Future<void> _loadUserName() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      final data = await Supabase.instance.client
          .from('user_profiles')
          .select('full_name')
          .eq('id', user.id)
          .maybeSingle();
      if (!mounted) return;
      final fullName = data?['full_name'] as String? ?? '';
      final firstName = fullName.isNotEmpty
          ? fullName.split(' ').first
          : (user.email?.split('@').first ?? '');
      setState(() => _displayName = firstName);
    } catch (_) {
      if (!mounted) return;
      final fallback = user.email?.split('@').first ?? '';
      setState(() => _displayName = fallback);
    }
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Avatar
        GestureDetector(
          onTap: widget.onSettingsTap,
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: AppTheme.primary.withAlpha(128),
                width: 2,
              ),
              gradient: const LinearGradient(
                colors: [Color(0xFF7C3AED), Color(0xFF5B21B6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Icon(
              Icons.person_rounded,
              color: Colors.white,
              size: 24,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _displayName.isNotEmpty
                    ? '${_getGreeting()}, $_displayName! 👋'
                    : '${_getGreeting()}! 👋',
                style: GoogleFonts.outfit(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Row(
                children: [
                  const Icon(
                    Icons.auto_awesome_rounded,
                    size: 12,
                    color: AppTheme.crystalAccent,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Ready to solve problems',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        // Notification bell
        GestureDetector(
          onTap: () {},
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.surfaceVariantDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.primary.withAlpha(51),
                width: 1,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Icon(
                  Icons.notifications_rounded,
                  size: 20,
                  color: AppTheme.textSecondary,
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: AppTheme.error,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
