import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/empty_state_widget.dart';
import '../../../widgets/status_badge_widget.dart';
import '../../../widgets/custom_image_widget.dart';

class _SolutionItem {
  final String id;
  final String subject;
  final String question;
  final String snippet;
  final String timeAgo;
  final String imageUrl;
  final String imageSemanticLabel;
  final BadgeStatus badgeStatus;
  final String statusLabel;
  final int crystalsUsed;

  const _SolutionItem({
    required this.id,
    required this.subject,
    required this.question,
    required this.snippet,
    required this.timeAgo,
    required this.imageUrl,
    required this.imageSemanticLabel,
    required this.badgeStatus,
    required this.statusLabel,
    required this.crystalsUsed,
  });
}

class RecentSolutionsWidget extends StatefulWidget {
  final int crystalBalance;
  final String selectedLanguage;

  const RecentSolutionsWidget({
    super.key,
    required this.crystalBalance,
    required this.selectedLanguage,
  });

  @override
  State<RecentSolutionsWidget> createState() => _RecentSolutionsWidgetState();
}

class _RecentSolutionsWidgetState extends State<RecentSolutionsWidget>
    with SingleTickerProviderStateMixin {
  // TODO: Replace with Riverpod/Bloc + Supabase query for real solution history
  final List<Map<String, dynamic>> _solutionMaps = [
    {
      'id': 'sol_001',
      'subject': 'Math',
      'question': 'Solve the quadratic equation: 3x² - 7x + 2 = 0',
      'snippet':
          'Using the quadratic formula: x = (7 ± √(49-24)) / 6 = (7 ± 5) / 6',
      'timeAgo': '12 min ago',
      'imageUrl':
          'https://img.rocket.new/generatedImages/rocket_gen_img_1d47966b6-1775105704341.png',
      'semanticLabel': 'Math textbook open on desk with pencil and equations',
      'badgeStatus': 'success',
      'statusLabel': 'Solved',
      'crystalsUsed': 10,
    },
    {
      'id': 'sol_002',
      'subject': 'Science',
      'question': 'Explain the process of photosynthesis in plants',
      'snippet':
          '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. Chlorophyll absorbs sunlight...',
      'timeAgo': '1 hr ago',
      'imageUrl':
          'https://images.unsplash.com/photo-1568131155896-7438ccf0afbd',
      'semanticLabel': 'Green plant leaf with sunlight filtering through',
      'badgeStatus': 'primary',
      'statusLabel': 'Science',
      'crystalsUsed': 10,
    },
    {
      'id': 'sol_003',
      'subject': 'History',
      'question': 'What were the main causes of World War I?',
      'snippet':
          'MAIN acronym: Militarism, Alliances, Imperialism, Nationalism. The assassination...',
      'timeAgo': '3 hrs ago',
      'imageUrl':
          'https://img.rocket.new/generatedImages/rocket_gen_img_1e4937bbb-1772069502818.png',
      'semanticLabel': 'Old history books stacked on wooden shelf',
      'badgeStatus': 'warning',
      'statusLabel': 'History',
      'crystalsUsed': 0,
    },
    {
      'id': 'sol_004',
      'subject': 'Chemistry',
      'question': 'Balance the equation: Fe + O₂ → Fe₂O₃',
      'snippet': '4Fe + 3O₂ → 2Fe₂O₃. Iron undergoes oxidation reaction...',
      'timeAgo': 'Yesterday',
      'imageUrl':
          'https://images.unsplash.com/photo-1595500381751-d940898d13a0',
      'semanticLabel':
          'Chemistry lab equipment with colorful liquids in flasks',
      'badgeStatus': 'error',
      'statusLabel': 'Chemistry',
      'crystalsUsed': 10,
    },
  ];

  late List<_SolutionItem> _solutions;

  @override
  void initState() {
    super.initState();
    _solutions = _solutionMaps.map((m) {
      return _SolutionItem(
        id: m['id'] as String,
        subject: m['subject'] as String,
        question: m['question'] as String,
        snippet: m['snippet'] as String,
        timeAgo: m['timeAgo'] as String,
        imageUrl: m['imageUrl'] as String,
        imageSemanticLabel: m['semanticLabel'] as String,
        badgeStatus: _badgeFromString(m['badgeStatus'] as String),
        statusLabel: m['statusLabel'] as String,
        crystalsUsed: m['crystalsUsed'] as int,
      );
    }).toList();
  }

  static BadgeStatus _badgeFromString(String v) {
    switch (v) {
      case 'success':
        return BadgeStatus.success;
      case 'warning':
        return BadgeStatus.warning;
      case 'error':
        return BadgeStatus.error;
      case 'primary':
        return BadgeStatus.primary;
      default:
        return BadgeStatus.muted;
    }
  }

  void _dismissSolution(String id) {
    setState(() {
      _solutions.removeWhere((s) => s.id == id);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_solutions.isEmpty) {
      return const EmptyStateWidget(
        iconName: 'auto_awesome',
        title: 'No solutions yet',
        description:
            'Type a problem above or take a photo to get your first AI-powered solution.',
        ctaLabel: 'Solve a Problem',
      );
    }

    return Column(
      children: List.generate(_solutions.length, (index) {
        final solution = _solutions[index];
        return _AnimatedSolutionCard(
          solution: solution,
          index: index,
          onDismiss: () => _dismissSolution(solution.id),
        );
      }),
    );
  }
}

class _AnimatedSolutionCard extends StatefulWidget {
  final _SolutionItem solution;
  final int index;
  final VoidCallback onDismiss;

  const _AnimatedSolutionCard({
    required this.solution,
    required this.index,
    required this.onDismiss,
  });

  @override
  State<_AnimatedSolutionCard> createState() => _AnimatedSolutionCardState();
}

class _AnimatedSolutionCardState extends State<_AnimatedSolutionCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 350 + widget.index * 60),
    )..forward();
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: Dismissible(
          key: Key(widget.solution.id),
          direction: DismissDirection.endToStart,
          onDismissed: (_) => widget.onDismiss(),
          background: Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: AppTheme.error.withAlpha(51),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppTheme.error.withAlpha(102),
                width: 1,
              ),
            ),
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            child: const Icon(
              Icons.delete_rounded,
              color: AppTheme.error,
              size: 24,
            ),
          ),
          child: _SolutionCardContent(solution: widget.solution),
        ),
      ),
    );
  }
}

class _SolutionCardContent extends StatelessWidget {
  final _SolutionItem solution;

  const _SolutionCardContent({required this.solution});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border(
          left: BorderSide(color: _subjectColor(solution.subject), width: 3),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(51),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          // Left: text content (60%)
          Expanded(
            flex: 6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    StatusBadgeWidget(
                      label: solution.subject,
                      status: solution.badgeStatus,
                    ),
                    const SizedBox(width: 8),
                    if (solution.crystalsUsed > 0)
                      Row(
                        children: [
                          const Icon(
                            Icons.diamond_rounded,
                            size: 11,
                            color: AppTheme.crystalAccent,
                          ),
                          const SizedBox(width: 2),
                          Text(
                            '${solution.crystalsUsed}',
                            style: GoogleFonts.outfit(
                              fontSize: 11,
                              color: AppTheme.crystalAccent,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  solution.question,
                  style: GoogleFonts.outfit(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  solution.snippet,
                  style: GoogleFonts.outfit(
                    fontSize: 11,
                    color: AppTheme.textMuted,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                Text(
                  solution.timeAgo,
                  style: GoogleFonts.outfit(
                    fontSize: 11,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          // Right: image (40%)
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: CustomImageWidget(
              imageUrl: solution.imageUrl,
              width: 80,
              height: 80,
              fit: BoxFit.cover,
              semanticLabel: solution.imageSemanticLabel,
            ),
          ),
        ],
      ),
    );
  }

  Color _subjectColor(String subject) {
    switch (subject) {
      case 'Math':
        return AppTheme.primary;
      case 'Science':
        return AppTheme.success;
      case 'History':
        return AppTheme.crystalAccent;
      case 'Chemistry':
        return AppTheme.error;
      default:
        return AppTheme.info;
    }
  }
}
