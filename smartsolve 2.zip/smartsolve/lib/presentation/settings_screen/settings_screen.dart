import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../routes/app_routes.dart';
import '../../theme/app_theme.dart';
import '../../services/stripe_payment_service.dart';
import '../../services/analytics_service.dart';
import './widgets/settings_crystal_widget.dart';
import './widgets/settings_danger_zone_widget.dart';
import './widgets/settings_language_widget.dart';
import './widgets/settings_preferences_widget.dart';
import './widgets/settings_profile_widget.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
    with SingleTickerProviderStateMixin {
  String _selectedLanguage = 'en';
  bool _notificationsEnabled = true;
  bool _soundEnabled = true;
  int _crystalBalance = 0;
  bool _isLoadingBalance = true;
  bool _isProcessingPayment = false;
  late AnimationController _entranceCtrl;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _entranceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    )..forward();
    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _loadPreferences();
    _loadCrystalBalance();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _selectedLanguage = prefs.getString('language') ?? 'en';
        _notificationsEnabled = prefs.getBool('notifications') ?? true;
        _soundEnabled = prefs.getBool('sound') ?? true;
      });
    }
  }

  Future<void> _loadCrystalBalance() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() => _isLoadingBalance = false);
      return;
    }
    try {
      final balance = await StripePaymentService.instance.getCrystalBalance(
        user.id,
      );
      if (mounted) {
        setState(() {
          _crystalBalance = balance;
          _isLoadingBalance = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _isLoadingBalance = false);
    }
  }

  Future<void> _saveLanguage(String lang) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', lang);
    setState(() => _selectedLanguage = lang);
  }

  Future<void> _saveNotifications(bool val) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications', val);
    setState(() => _notificationsEnabled = val);
  }

  Future<void> _saveSound(bool val) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sound', val);
    setState(() => _soundEnabled = val);
  }

  Future<void> _onBuyCrystals(int amount, double price) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      Fluttertoast.showToast(
        msg: _selectedLanguage == 'ru'
            ? 'Войдите в аккаунт для покупки'
            : 'Please sign in to purchase crystals',
        backgroundColor: AppTheme.error,
      );
      return;
    }

    if (_isProcessingPayment) return;
    setState(() => _isProcessingPayment = true);

    await AnalyticsService.instance.trackPurchaseStarted(
      crystalAmount: amount,
      priceUsd: price,
    );

    final isRu = _selectedLanguage == 'ru';
    final packLabel = amount == 100
        ? (isRu ? '100 кристаллов' : '100 Crystals')
        : amount == 500
        ? (isRu ? '500 кристаллов' : '500 Crystals')
        : (isRu ? '1000 кристаллов' : '1000 Crystals');

    final result = await StripePaymentService.instance.purchaseCrystalPack(
      userId: user.id,
      userEmail: user.email ?? '',
      crystalAmount: amount,
      priceUsd: price,
      packLabel: packLabel,
    );

    if (!mounted) return;
    setState(() => _isProcessingPayment = false);

    if (result.isSuccess) {
      await AnalyticsService.instance.trackPurchaseCompleted(
        crystalAmount: amount,
        priceUsd: price,
      );
      // Navigate to confirmation screen with purchase details
      if (mounted) {
        Navigator.pushNamed(
          context,
          AppRoutes.paymentConfirmationScreen,
          arguments: {
            'crystalAmount': amount,
            'priceUsd': price,
            'transactionId': result.transactionId,
          },
        );
      }
      // Refresh balance after returning from confirmation screen
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _loadCrystalBalance();
      });
    } else if (result.isCancelled) {
      await AnalyticsService.instance.trackPurchaseCancelled(
        crystalAmount: amount,
      );
      // User cancelled — no message needed
    } else {
      await AnalyticsService.instance.trackPurchaseFailed(
        crystalAmount: amount,
        reason: result.message,
      );
      Fluttertoast.showToast(
        msg: result.message,
        backgroundColor: AppTheme.error,
        toastLength: Toast.LENGTH_LONG,
      );
    }
  }

  void _onSignOut() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          _selectedLanguage == 'ru' ? 'Выйти' : 'Sign Out',
          style: GoogleFonts.outfit(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
          ),
        ),
        content: Text(
          _selectedLanguage == 'ru'
              ? 'Вы уверены, что хотите выйти?'
              : 'Are you sure you want to sign out?',
          style: GoogleFonts.outfit(
            color: AppTheme.textSecondary,
            fontSize: 14,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              _selectedLanguage == 'ru' ? 'Отмена' : 'Cancel',
              style: GoogleFonts.outfit(color: AppTheme.textMuted),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await AnalyticsService.instance.trackSignOut();
              await Supabase.instance.client.auth.signOut();
              if (mounted) {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  AppRoutes.signUpLoginScreen,
                  (route) => false,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.error,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              _selectedLanguage == 'ru' ? 'Выйти' : 'Sign Out',
              style: GoogleFonts.outfit(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  void _onDeleteAccount() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surfaceDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.warning_rounded, color: AppTheme.error, size: 22),
            const SizedBox(width: 8),
            Text(
              _selectedLanguage == 'ru' ? 'Удалить аккаунт' : 'Delete Account',
              style: GoogleFonts.outfit(
                color: AppTheme.error,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        content: Text(
          _selectedLanguage == 'ru'
              ? 'Это действие необратимо. Все ваши данные и кристаллы будут удалены.'
              : 'This action is permanent and cannot be undone. All your solutions, crystal balance, and data will be deleted.',
          style: GoogleFonts.outfit(
            color: AppTheme.textSecondary,
            fontSize: 14,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              _selectedLanguage == 'ru' ? 'Отмена' : 'Cancel',
              style: GoogleFonts.outfit(color: AppTheme.textMuted),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.error,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: Text(
              _selectedLanguage == 'ru' ? 'Удалить навсегда' : 'Delete Forever',
              style: GoogleFonts.outfit(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fade,
          child: Stack(
            children: [
              Column(
                children: [
                  _buildAppBar(context),
                  Expanded(
                    child: isTablet
                        ? _buildTabletLayout()
                        : _buildPhoneLayout(),
                  ),
                ],
              ),
              if (_isProcessingPayment)
                Container(
                  color: Colors.black.withAlpha(153),
                  child: const Center(
                    child: CircularProgressIndicator(
                      color: AppTheme.crystalAccent,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.primary.withAlpha(38), AppTheme.backgroundDark],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppTheme.surfaceVariantDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.primary.withAlpha(51),
                  width: 1,
                ),
              ),
              child: const Icon(
                Icons.arrow_back_ios_rounded,
                size: 18,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Text(
            _selectedLanguage == 'ru' ? 'Настройки' : 'Settings',
            style: GoogleFonts.outfit(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppTheme.textPrimary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneLayout() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),
          SettingsProfileWidget(
            selectedLanguage: _selectedLanguage,
            crystalBalance: _crystalBalance,
          ),
          const SizedBox(height: 20),
          SettingsCrystalWidget(
            balance: _crystalBalance,
            selectedLanguage: _selectedLanguage,
            onBuy: _onBuyCrystals,
            isLoadingBalance: _isLoadingBalance,
          ),
          const SizedBox(height: 20),
          SettingsLanguageWidget(
            selectedLanguage: _selectedLanguage,
            onLanguageChanged: _saveLanguage,
          ),
          const SizedBox(height: 20),
          SettingsPreferencesWidget(
            notificationsEnabled: _notificationsEnabled,
            soundEnabled: _soundEnabled,
            selectedLanguage: _selectedLanguage,
            onNotificationsChanged: _saveNotifications,
            onSoundChanged: _saveSound,
          ),
          const SizedBox(height: 20),
          SettingsDangerZoneWidget(
            selectedLanguage: _selectedLanguage,
            onSignOut: _onSignOut,
            onDeleteAccount: _onDeleteAccount,
          ),
          const SizedBox(height: 20),
          _buildLogsButton(context),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildTabletLayout() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              children: [
                const SizedBox(height: 8),
                SettingsProfileWidget(
                  selectedLanguage: _selectedLanguage,
                  crystalBalance: _crystalBalance,
                ),
                const SizedBox(height: 20),
                SettingsCrystalWidget(
                  balance: _crystalBalance,
                  selectedLanguage: _selectedLanguage,
                  onBuy: _onBuyCrystals,
                  isLoadingBalance: _isLoadingBalance,
                ),
                const SizedBox(height: 20),
                SettingsDangerZoneWidget(
                  selectedLanguage: _selectedLanguage,
                  onSignOut: _onSignOut,
                  onDeleteAccount: _onDeleteAccount,
                ),
                const SizedBox(height: 20),
                _buildLogsButton(context),
                const SizedBox(height: 32),
              ],
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              children: [
                const SizedBox(height: 8),
                SettingsLanguageWidget(
                  selectedLanguage: _selectedLanguage,
                  onLanguageChanged: _saveLanguage,
                ),
                const SizedBox(height: 20),
                SettingsPreferencesWidget(
                  notificationsEnabled: _notificationsEnabled,
                  soundEnabled: _soundEnabled,
                  selectedLanguage: _selectedLanguage,
                  onNotificationsChanged: _saveNotifications,
                  onSoundChanged: _saveSound,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogsButton(BuildContext context) {
    return Column(
      children: [
        _buildAnalyticsButton(context),
        const SizedBox(height: 12),
        _buildErrorLogsButton(context),
      ],
    );
  }

  Widget _buildAnalyticsButton(BuildContext context) {
    return GestureDetector(
      onTap: () =>
          Navigator.pushNamed(context, AppRoutes.analyticsDashboardScreen),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.primary.withAlpha(77), width: 1),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppTheme.primary.withAlpha(30),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.bar_chart_rounded,
                color: AppTheme.primary,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Analytics',
                    style: GoogleFonts.outfit(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'Engagement, solves & drop-off metrics',
                    style: GoogleFonts.outfit(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.textMuted,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorLogsButton(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, AppRoutes.logsDashboardScreen),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppTheme.surfaceDark,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.error.withAlpha(77), width: 1),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppTheme.error.withAlpha(30),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.bug_report_rounded,
                color: AppTheme.error,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Error Logs',
                    style: GoogleFonts.outfit(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    'View crashes, API errors & failures',
                    style: GoogleFonts.outfit(
                      color: AppTheme.textMuted,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right_rounded,
              color: AppTheme.textMuted,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}
