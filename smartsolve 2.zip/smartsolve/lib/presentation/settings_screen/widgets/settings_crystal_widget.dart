import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class SettingsCrystalWidget extends StatelessWidget {
  final int balance;
  final String selectedLanguage;
  final void Function(int amount, double price) onBuy;
  final bool isLoadingBalance;

  const SettingsCrystalWidget({
    super.key,
    required this.balance,
    required this.selectedLanguage,
    required this.onBuy,
    this.isLoadingBalance = false,
  });

  @override
  Widget build(BuildContext context) {
    final isRu = selectedLanguage == 'ru';

    final List<Map<String, dynamic>> packs = [
      {
        'amount': 100,
        'price': 0.99,
        'label': isRu ? '100 кристаллов' : '100 Crystals',
        'badge': null,
        'popular': false,
      },
      {
        'amount': 500,
        'price': 3.99,
        'label': isRu ? '500 кристаллов' : '500 Crystals',
        'badge': isRu ? 'Популярный' : 'Popular',
        'popular': true,
      },
      {
        'amount': 1000,
        'price': 6.99,
        'label': isRu ? '1000 кристаллов' : '1000 Crystals',
        'badge': isRu ? 'Лучшая цена' : 'Best Value',
        'popular': false,
      },
    ];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border(
          left: BorderSide(color: AppTheme.crystalAccent, width: 3),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(51),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  gradient: AppTheme.crystalGradient,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.diamond_rounded,
                  size: 18,
                  color: Colors.black,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                isRu ? 'Купить кристаллы' : 'Buy Crystals',
                style: GoogleFonts.outfit(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
              ),
              const Spacer(),
              Row(
                children: [
                  const Icon(
                    Icons.diamond_rounded,
                    size: 14,
                    color: AppTheme.crystalAccent,
                  ),
                  const SizedBox(width: 4),
                  isLoadingBalance
                      ? SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: AppTheme.crystalAccent,
                          ),
                        )
                      : Text(
                          '$balance',
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.crystalLight,
                            fontFeatures: [const FontFeature.tabularFigures()],
                          ),
                        ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            isRu
                ? 'Каждое решение стоит 10 кристаллов. Оплата через Stripe (Google Pay / Apple Pay). Кристаллы зачисляются после подтверждения платежа.'
                : 'Each AI solution costs 10 crystals. Pay via Stripe (Google Pay / Apple Pay). Crystals are credited after payment confirmation.',
            style: GoogleFonts.outfit(
              fontSize: 12,
              color: AppTheme.textMuted,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          ...packs.map(
            (pack) => _CrystalPack(
              pack: pack,
              onBuy: () =>
                  onBuy(pack['amount'] as int, pack['price'] as double),
              selectedLanguage: selectedLanguage,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.lock_rounded,
                size: 12,
                color: AppTheme.textMuted,
              ),
              const SizedBox(width: 4),
              Text(
                isRu
                    ? 'Безопасная оплата через Stripe'
                    : 'Secured by Stripe — LIVE payments',
                style: GoogleFonts.outfit(
                  fontSize: 11,
                  color: AppTheme.textMuted,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _CrystalPack extends StatefulWidget {
  final Map<String, dynamic> pack;
  final VoidCallback onBuy;
  final String selectedLanguage;

  const _CrystalPack({
    required this.pack,
    required this.onBuy,
    required this.selectedLanguage,
  });

  @override
  State<_CrystalPack> createState() => _CrystalPackState();
}

class _CrystalPackState extends State<_CrystalPack>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
      lowerBound: 0.97,
      upperBound: 1.0,
      value: 1.0,
    );
    _scale = _ctrl;
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isPopular = widget.pack['popular'] as bool;
    final badge = widget.pack['badge'] as String?;
    final isRu = widget.selectedLanguage == 'ru';

    return GestureDetector(
      onTapDown: (_) => _ctrl.reverse(),
      onTapUp: (_) {
        _ctrl.forward();
        widget.onBuy();
      },
      onTapCancel: () => _ctrl.forward(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: isPopular
                ? AppTheme.crystalAccent.withAlpha(26)
                : AppTheme.surfaceVariantDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: isPopular
                  ? AppTheme.crystalAccent.withAlpha(128)
                  : AppTheme.surfaceElevatedDark,
              width: 1.5,
            ),
          ),
          child: Row(
            children: [
              // Crystal icon
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.crystalAccent.withAlpha(38),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.diamond_rounded,
                  size: 20,
                  color: AppTheme.crystalAccent,
                ),
              ),
              const SizedBox(width: 12),
              // Label + badge
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          widget.pack['label'] as String,
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        if (badge != null) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: isPopular
                                  ? AppTheme.crystalAccent
                                  : AppTheme.success,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              badge,
                              style: GoogleFonts.outfit(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    Text(
                      isRu
                          ? '= ${widget.pack['amount'] ~/ 10} решений ИИ'
                          : '= ${widget.pack['amount'] ~/ 10} AI solutions',
                      style: GoogleFonts.outfit(
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              // Price
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  gradient: isPopular ? AppTheme.crystalGradient : null,
                  color: isPopular ? null : AppTheme.surfaceElevatedDark,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  '\$${(widget.pack['price'] as double).toStringAsFixed(2)}',
                  style: GoogleFonts.outfit(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: isPopular ? Colors.black : AppTheme.textPrimary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
