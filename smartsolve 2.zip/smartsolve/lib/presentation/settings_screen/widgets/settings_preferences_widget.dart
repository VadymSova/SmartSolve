import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class SettingsPreferencesWidget extends StatelessWidget {
  final bool notificationsEnabled;
  final bool soundEnabled;
  final String selectedLanguage;
  final ValueChanged<bool> onNotificationsChanged;
  final ValueChanged<bool> onSoundChanged;

  const SettingsPreferencesWidget({
    super.key,
    required this.notificationsEnabled,
    required this.soundEnabled,
    required this.selectedLanguage,
    required this.onNotificationsChanged,
    required this.onSoundChanged,
  });

  @override
  Widget build(BuildContext context) {
    final isRu = selectedLanguage == 'ru';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border(left: BorderSide(color: AppTheme.success, width: 3)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(51),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppTheme.success.withAlpha(38),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.tune_rounded,
                  size: 18,
                  color: AppTheme.success,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                isRu ? 'Настройки' : 'Preferences',
                style: GoogleFonts.outfit(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _PreferenceRow(
            icon: Icons.notifications_rounded,
            iconColor: AppTheme.primary,
            label: isRu ? 'Уведомления' : 'Notifications',
            description: isRu
                ? 'Получать уведомления о решениях'
                : 'Receive solution notifications',
            value: notificationsEnabled,
            onChanged: onNotificationsChanged,
          ),
          const SizedBox(height: 4),
          Container(height: 1, color: AppTheme.surfaceVariantDark),
          const SizedBox(height: 4),
          _PreferenceRow(
            icon: Icons.volume_up_rounded,
            iconColor: AppTheme.crystalAccent,
            label: isRu ? 'Звуки' : 'Sound Effects',
            description: isRu
                ? 'Звуки при получении решений'
                : 'Play sounds on solution received',
            value: soundEnabled,
            onChanged: onSoundChanged,
          ),
        ],
      ),
    );
  }
}

class _PreferenceRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String description;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _PreferenceRow({
    required this.icon,
    required this.iconColor,
    required this.label,
    required this.description,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: iconColor.withAlpha(31),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, size: 16, color: iconColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.outfit(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                  ),
                ),
                Text(
                  description,
                  style: GoogleFonts.outfit(
                    fontSize: 11,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: Colors.white,
            activeTrackColor: AppTheme.primary,
            inactiveThumbColor: AppTheme.textMuted,
            inactiveTrackColor: AppTheme.surfaceVariantDark,
          ),
        ],
      ),
    );
  }
}
