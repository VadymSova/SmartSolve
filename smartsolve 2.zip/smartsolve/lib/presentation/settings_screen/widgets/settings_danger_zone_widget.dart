import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class SettingsDangerZoneWidget extends StatelessWidget {
  final String selectedLanguage;
  final VoidCallback onSignOut;
  final VoidCallback onDeleteAccount;

  const SettingsDangerZoneWidget({
    super.key,
    required this.selectedLanguage,
    required this.onSignOut,
    required this.onDeleteAccount,
  });

  @override
  Widget build(BuildContext context) {
    final isRu = selectedLanguage == 'ru';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.surfaceDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.error.withAlpha(77), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: AppTheme.error.withAlpha(20),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppTheme.error.withAlpha(38),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.warning_rounded,
                  size: 18,
                  color: AppTheme.error,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                isRu ? 'Опасная зона' : 'Danger Zone',
                style: GoogleFonts.outfit(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.error,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Sign out button
          _DangerButton(
            icon: Icons.logout_rounded,
            label: isRu ? 'Выйти из аккаунта' : 'Sign Out',
            description: isRu
                ? 'Выйти на всех устройствах'
                : 'Sign out from all devices',
            isDestructive: false,
            onTap: onSignOut,
          ),
          const SizedBox(height: 10),
          // Delete account button
          _DangerButton(
            icon: Icons.delete_forever_rounded,
            label: isRu ? 'Удалить аккаунт' : 'Delete Account',
            description: isRu
                ? 'Необратимое удаление всех данных'
                : 'Permanently delete all your data',
            isDestructive: true,
            onTap: onDeleteAccount,
          ),
        ],
      ),
    );
  }
}

class _DangerButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final String description;
  final bool isDestructive;
  final VoidCallback onTap;

  const _DangerButton({
    required this.icon,
    required this.label,
    required this.description,
    required this.isDestructive,
    required this.onTap,
  });

  @override
  State<_DangerButton> createState() => _DangerButtonState();
}

class _DangerButtonState extends State<_DangerButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
      lowerBound: 0.97,
      upperBound: 1.0,
      value: 1.0,
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.isDestructive
        ? AppTheme.error
        : AppTheme.textSecondary;

    return GestureDetector(
      onTapDown: (_) => _ctrl.reverse(),
      onTapUp: (_) {
        _ctrl.forward();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.forward(),
      child: ScaleTransition(
        scale: _ctrl,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: widget.isDestructive
                ? AppTheme.error.withAlpha(20)
                : AppTheme.surfaceVariantDark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: widget.isDestructive
                  ? AppTheme.error.withAlpha(77)
                  : AppTheme.surfaceElevatedDark,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Icon(widget.icon, size: 20, color: color),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.label,
                      style: GoogleFonts.outfit(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: color,
                      ),
                    ),
                    Text(
                      widget.description,
                      style: GoogleFonts.outfit(
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios_rounded,
                size: 14,
                color: color.withAlpha(153),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
