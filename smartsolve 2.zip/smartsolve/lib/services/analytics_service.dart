import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';

/// Tracks user events and session metrics to Supabase analytics tables.
class AnalyticsService {
  static AnalyticsService? _instance;
  static AnalyticsService get instance => _instance ??= AnalyticsService._();
  AnalyticsService._();

  SupabaseClient get _client => Supabase.instance.client;

  String? _sessionId;
  DateTime? _sessionStart;
  int _sessionSolves = 0;
  int _sessionErrors = 0;

  // UTM params captured on first open
  Map<String, String?> _utmParams = {};

  String get _platform {
    if (kIsWeb) return 'web';
    return defaultTargetPlatform.name.toLowerCase();
  }

  String? get _userId {
    try {
      return _client.auth.currentUser?.id;
    } catch (_) {
      return null;
    }
  }

  String _generateSessionId() {
    final rand = Random.secure();
    final bytes = List<int>.generate(16, (_) => rand.nextInt(256));
    return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  // ── UTM / Campaign Attribution ────────────────────────────────────────────

  /// Call once on app first open with any UTM parameters from deep link / referrer.
  /// Stores params locally and persists to Supabase.
  Future<void> captureUtmParams({
    String? utmSource,
    String? utmMedium,
    String? utmCampaign,
    String? utmTerm,
    String? utmContent,
    String? referrer,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final alreadyCaptured = prefs.getBool('utm_captured') ?? false;
      if (alreadyCaptured) {
        // Restore cached params for linking to conversions
        _utmParams = {
          'utm_source': prefs.getString('utm_source'),
          'utm_medium': prefs.getString('utm_medium'),
          'utm_campaign': prefs.getString('utm_campaign'),
          'utm_term': prefs.getString('utm_term'),
          'utm_content': prefs.getString('utm_content'),
          'referrer': prefs.getString('utm_referrer'),
        };
        return;
      }

      _utmParams = {
        'utm_source': utmSource,
        'utm_medium': utmMedium,
        'utm_campaign': utmCampaign,
        'utm_term': utmTerm,
        'utm_content': utmContent,
        'referrer': referrer,
      };

      // Persist locally so we only capture once per install
      await prefs.setBool('utm_captured', true);
      if (utmSource != null) await prefs.setString('utm_source', utmSource);
      if (utmMedium != null) await prefs.setString('utm_medium', utmMedium);
      if (utmCampaign != null)
        await prefs.setString('utm_campaign', utmCampaign);
      if (utmTerm != null) await prefs.setString('utm_term', utmTerm);
      if (utmContent != null) await prefs.setString('utm_content', utmContent);
      if (referrer != null) await prefs.setString('utm_referrer', referrer);

      await _client.from('campaign_attributions').insert({
        'user_id': _userId,
        'session_id': _sessionId,
        'utm_source': utmSource,
        'utm_medium': utmMedium,
        'utm_campaign': utmCampaign,
        'utm_term': utmTerm,
        'utm_content': utmContent,
        'referrer': referrer,
        'platform': _platform,
      });
    } catch (e) {
      debugPrint('[Analytics] captureUtmParams failed: $e');
    }
  }

  /// Restore UTM params from local storage (call after app restart).
  Future<void> restoreUtmParams() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _utmParams = {
        'utm_source': prefs.getString('utm_source'),
        'utm_medium': prefs.getString('utm_medium'),
        'utm_campaign': prefs.getString('utm_campaign'),
        'utm_term': prefs.getString('utm_term'),
        'utm_content': prefs.getString('utm_content'),
        'referrer': prefs.getString('utm_referrer'),
      };
    } catch (e) {
      debugPrint('[Analytics] restoreUtmParams failed: $e');
    }
  }

  /// Link a conversion event to the stored UTM attribution.
  Future<void> _linkConversionToAttribution(String conversionType) async {
    try {
      final source = _utmParams['utm_source'];
      if (source == null) return; // No UTM params to link

      await _client
          .from('campaign_attributions')
          .update({
            'converted': true,
            'converted_at': DateTime.now().toIso8601String(),
            'conversion_type': conversionType,
          })
          .eq('platform', _platform)
          .eq('utm_source', source)
          .eq('converted', false);
    } catch (e) {
      debugPrint('[Analytics] _linkConversionToAttribution failed: $e');
    }
  }

  // ── Cohort Tracking ───────────────────────────────────────────────────────

  /// Upsert cohort record for the current user after sign-up.
  Future<void> upsertUserCohort({String? signupMethod}) async {
    final uid = _userId;
    if (uid == null) return;
    try {
      final now = DateTime.now();
      // ISO week: YYYY-Www
      final weekNum = _isoWeekNumber(now);
      final cohortWeek = '${now.year}-W${weekNum.toString().padLeft(2, '0')}';
      final cohortMonth = '${now.year}-${now.month.toString().padLeft(2, '0')}';

      await _client
          .from('user_cohorts')
          .upsert(
            {
              'user_id': uid,
              'cohort_week': cohortWeek,
              'cohort_month': cohortMonth,
              'signup_platform': _platform,
              'signup_method': signupMethod ?? 'email',
              'updated_at': now.toIso8601String(),
            },
            onConflict: 'user_id',
            ignoreDuplicates: false,
          );
    } catch (e) {
      debugPrint('[Analytics] upsertUserCohort failed: $e');
    }
  }

  /// Increment solve count in cohort and record first solve timestamp.
  Future<void> _updateCohortOnSolve() async {
    final uid = _userId;
    if (uid == null) return;
    try {
      final rows =
          await _client
                  .from('user_cohorts')
                  .select('total_solves, first_solve_at')
                  .eq('user_id', uid)
                  .limit(1)
              as List<dynamic>;

      if (rows.isEmpty) return;
      final current = rows.first as Map<String, dynamic>;
      final solves = (current['total_solves'] as int? ?? 0) + 1;
      final firstSolve = current['first_solve_at'];

      await _client
          .from('user_cohorts')
          .update({
            'total_solves': solves,
            if (firstSolve == null)
              'first_solve_at': DateTime.now().toIso8601String(),
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('user_id', uid);
    } catch (e) {
      debugPrint('[Analytics] _updateCohortOnSolve failed: $e');
    }
  }

  /// Increment purchase count and revenue in cohort.
  Future<void> _updateCohortOnPurchase({double? priceUsd}) async {
    final uid = _userId;
    if (uid == null) return;
    try {
      final rows =
          await _client
                  .from('user_cohorts')
                  .select('total_purchases, total_spent_usd, first_purchase_at')
                  .eq('user_id', uid)
                  .limit(1)
              as List<dynamic>;

      if (rows.isEmpty) return;
      final current = rows.first as Map<String, dynamic>;
      final purchases = (current['total_purchases'] as int? ?? 0) + 1;
      final spent =
          (current['total_spent_usd'] as num? ?? 0).toDouble() +
          (priceUsd ?? 0);
      final firstPurchase = current['first_purchase_at'];

      await _client
          .from('user_cohorts')
          .update({
            'total_purchases': purchases,
            'total_spent_usd': spent,
            if (firstPurchase == null)
              'first_purchase_at': DateTime.now().toIso8601String(),
            'updated_at': DateTime.now().toIso8601String(),
          })
          .eq('user_id', uid);
    } catch (e) {
      debugPrint('[Analytics] _updateCohortOnPurchase failed: $e');
    }
  }

  // ── Funnel Step Tracking ──────────────────────────────────────────────────

  /// Record a step in a named funnel.
  Future<void> trackFunnelStep({
    required String funnelName,
    required String stepName,
    required int stepOrder,
    Map<String, dynamic>? properties,
  }) async {
    try {
      await _client.from('funnel_steps').insert({
        'user_id': _userId,
        'session_id': _sessionId,
        'funnel_name': funnelName,
        'step_name': stepName,
        'step_order': stepOrder,
        'platform': _platform,
        if (properties != null) 'properties': properties,
      });
    } catch (e) {
      debugPrint('[Analytics] trackFunnelStep failed: $e');
    }
  }

  // ── Session ──────────────────────────────────────────────────────────────

  /// Call when app foregrounds or user logs in.
  Future<void> startSession() async {
    _sessionId = _generateSessionId();
    _sessionStart = DateTime.now();
    _sessionSolves = 0;
    _sessionErrors = 0;

    await _trackEvent('session_start', properties: {'session_id': _sessionId});

    try {
      await _client.from('session_metrics').insert({
        'user_id': _userId,
        'session_id': _sessionId,
        'started_at': _sessionStart!.toIso8601String(),
        'platform': _platform,
      });
    } catch (e) {
      debugPrint('[Analytics] startSession insert failed: $e');
    }
  }

  /// Call when app backgrounds or user logs out.
  Future<void> endSession() async {
    if (_sessionId == null || _sessionStart == null) return;

    final ended = DateTime.now();
    final duration = ended.difference(_sessionStart!).inSeconds;

    await _trackEvent(
      'session_end',
      properties: {
        'session_id': _sessionId,
        'duration_secs': duration,
        'solves': _sessionSolves,
        'errors': _sessionErrors,
      },
    );

    try {
      await _client
          .from('session_metrics')
          .update({
            'ended_at': ended.toIso8601String(),
            'duration_secs': duration,
            'solves_count': _sessionSolves,
            'errors_count': _sessionErrors,
          })
          .eq('session_id', _sessionId!);
    } catch (e) {
      debugPrint('[Analytics] endSession update failed: $e');
    }

    _sessionId = null;
    _sessionStart = null;
  }

  // ── Auth Events ──────────────────────────────────────────────────────────

  Future<void> trackSignIn({String? method}) async {
    await _trackEvent(
      'auth_sign_in',
      properties: {'method': method ?? 'email'},
    );
    // Funnel: auth step
    await trackFunnelStep(
      funnelName: 'core_conversion',
      stepName: 'signed_in',
      stepOrder: 1,
      properties: {'method': method ?? 'email'},
    );
  }

  Future<void> trackSignUp({String? method}) async {
    await _trackEvent(
      'auth_sign_up',
      properties: {'method': method ?? 'email'},
    );
    await upsertUserCohort(signupMethod: method);
    // Funnel: auth step
    await trackFunnelStep(
      funnelName: 'core_conversion',
      stepName: 'signed_up',
      stepOrder: 1,
      properties: {'method': method ?? 'email'},
    );
  }

  Future<void> trackSignOut() async {
    await _trackEvent('auth_sign_out');
    await endSession();
  }

  Future<void> trackAuthError({String? reason, String? method}) async {
    _sessionErrors++;
    await _trackEvent(
      'auth_error',
      properties: {'reason': reason, 'method': method ?? 'email'},
    );
  }

  // ── Solve Events ─────────────────────────────────────────────────────────

  Future<void> trackSolveStarted({String? source}) async {
    await _trackEvent(
      'solve_started',
      properties: {'source': source ?? 'camera'},
    );
    await trackFunnelStep(
      funnelName: 'core_conversion',
      stepName: 'solve_started',
      stepOrder: 2,
      properties: {'source': source ?? 'camera'},
    );
  }

  Future<void> trackSolveCompleted({String? source, int? durationMs}) async {
    _sessionSolves++;
    await _trackEvent(
      'solve_completed',
      properties: {
        'source': source ?? 'camera',
        if (durationMs != null) 'duration_ms': durationMs,
      },
    );
    await _updateCohortOnSolve();
    await trackFunnelStep(
      funnelName: 'core_conversion',
      stepName: 'solve_completed',
      stepOrder: 3,
      properties: {'source': source ?? 'camera'},
    );
  }

  Future<void> trackSolveFailed({String? source, String? reason}) async {
    _sessionErrors++;
    await _trackEvent(
      'solve_failed',
      properties: {'source': source ?? 'camera', 'reason': reason},
    );
  }

  Future<void> trackSolveRetried({String? source}) async {
    await _trackEvent(
      'solve_retried',
      properties: {'source': source ?? 'camera'},
    );
  }

  // ── Camera Events ────────────────────────────────────────────────────────

  Future<void> trackCameraOpened() async {
    await _trackEvent('camera_opened');
  }

  Future<void> trackCameraCaptured() async {
    await _trackEvent('camera_captured');
  }

  Future<void> trackGalleryPicked() async {
    await _trackEvent('gallery_picked');
  }

  // ── Purchase Events ──────────────────────────────────────────────────────

  Future<void> trackPurchaseStarted({
    int? crystalAmount,
    double? priceUsd,
  }) async {
    await _trackEvent(
      'purchase_started',
      properties: {
        if (crystalAmount != null) 'crystal_amount': crystalAmount,
        if (priceUsd != null) 'price_usd': priceUsd,
      },
    );
    await trackFunnelStep(
      funnelName: 'purchase_funnel',
      stepName: 'purchase_started',
      stepOrder: 1,
      properties: {
        if (crystalAmount != null) 'crystal_amount': crystalAmount,
        if (priceUsd != null) 'price_usd': priceUsd,
      },
    );
  }

  Future<void> trackPurchaseCompleted({
    int? crystalAmount,
    double? priceUsd,
  }) async {
    await _trackEvent(
      'purchase_completed',
      properties: {
        if (crystalAmount != null) 'crystal_amount': crystalAmount,
        if (priceUsd != null) 'price_usd': priceUsd,
      },
    );
    await _updateCohortOnPurchase(priceUsd: priceUsd);
    await _linkConversionToAttribution('purchase');
    await trackFunnelStep(
      funnelName: 'purchase_funnel',
      stepName: 'purchase_completed',
      stepOrder: 2,
      properties: {
        if (crystalAmount != null) 'crystal_amount': crystalAmount,
        if (priceUsd != null) 'price_usd': priceUsd,
      },
    );
  }

  Future<void> trackPurchaseFailed({int? crystalAmount, String? reason}) async {
    _sessionErrors++;
    await _trackEvent(
      'purchase_failed',
      properties: {
        if (crystalAmount != null) 'crystal_amount': crystalAmount,
        'reason': reason,
      },
    );
  }

  Future<void> trackPurchaseCancelled({int? crystalAmount}) async {
    await _trackEvent(
      'purchase_cancelled',
      properties: {if (crystalAmount != null) 'crystal_amount': crystalAmount},
    );
  }

  // ── Error Events ─────────────────────────────────────────────────────────

  Future<void> trackCrash({String? message, String? screen}) async {
    _sessionErrors++;
    await _trackEvent(
      'error_crash',
      properties: {'message': message, 'screen': screen},
    );
  }

  Future<void> trackApiError({
    String? endpoint,
    int? statusCode,
    String? message,
  }) async {
    _sessionErrors++;
    await _trackEvent(
      'error_api',
      properties: {
        'endpoint': endpoint,
        if (statusCode != null) 'status_code': statusCode,
        'message': message,
      },
    );
  }

  Future<void> trackNetworkError({String? message}) async {
    _sessionErrors++;
    await _trackEvent('error_network', properties: {'message': message});
  }

  // ── Core ─────────────────────────────────────────────────────────────────

  Future<void> _trackEvent(
    String eventType, {
    Map<String, dynamic>? properties,
  }) async {
    debugPrint('[Analytics] $eventType ${properties ?? ''}');
    try {
      final props = <String, dynamic>{
        if (_sessionId != null) 'session_id': _sessionId,
        ...?properties,
      };
      await _client.from('user_events').insert({
        'user_id': _userId,
        'event_type': eventType,
        'properties': props.isEmpty ? null : props,
        'platform': _platform,
      });
    } catch (e) {
      debugPrint('[Analytics] _trackEvent failed: $e');
    }
  }

  // ── Dashboard Queries ─────────────────────────────────────────────────────

  /// Returns event counts grouped by type for the last [days] days.
  Future<Map<String, int>> fetchEventCounts({int days = 7}) async {
    try {
      final since = DateTime.now()
          .subtract(Duration(days: days))
          .toIso8601String();
      final rows =
          await _client
                  .from('user_events')
                  .select('event_type')
                  .gte('created_at', since)
              as List<dynamic>;

      final counts = <String, int>{};
      for (final row in rows) {
        final t = row['event_type'] as String;
        counts[t] = (counts[t] ?? 0) + 1;
      }
      return counts;
    } catch (e) {
      debugPrint('[Analytics] fetchEventCounts failed: $e');
      return {};
    }
  }

  /// Returns recent events for the dashboard feed.
  Future<List<Map<String, dynamic>>> fetchRecentEvents({
    int limit = 50,
    String? filterType,
  }) async {
    try {
      var query = _client
          .from('user_events')
          .select('id, user_id, event_type, properties, platform, created_at');

      if (filterType != null) {
        query = query.eq('event_type', filterType);
      }

      final rows =
          await query.order('created_at', ascending: false).limit(limit)
              as List<dynamic>;

      return rows.cast<Map<String, dynamic>>();
    } catch (e) {
      debugPrint('[Analytics] fetchRecentEvents failed: $e');
      return [];
    }
  }

  /// Returns session metrics summary.
  Future<Map<String, dynamic>> fetchSessionSummary({int days = 7}) async {
    try {
      final since = DateTime.now()
          .subtract(Duration(days: days))
          .toIso8601String();
      final rows =
          await _client
                  .from('session_metrics')
                  .select('duration_secs, solves_count, errors_count')
                  .gte('started_at', since)
              as List<dynamic>;

      if (rows.isEmpty) {
        return {
          'sessions': 0,
          'avg_duration': 0,
          'total_solves': 0,
          'total_errors': 0,
        };
      }

      int totalDuration = 0;
      int totalSolves = 0;
      int totalErrors = 0;
      int validDurations = 0;

      for (final r in rows) {
        final d = r['duration_secs'] as int?;
        if (d != null) {
          totalDuration += d;
          validDurations++;
        }
        totalSolves += (r['solves_count'] as int? ?? 0);
        totalErrors += (r['errors_count'] as int? ?? 0);
      }

      return {
        'sessions': rows.length,
        'avg_duration': validDurations > 0
            ? (totalDuration / validDurations).round()
            : 0,
        'total_solves': totalSolves,
        'total_errors': totalErrors,
      };
    } catch (e) {
      debugPrint('[Analytics] fetchSessionSummary failed: $e');
      return {
        'sessions': 0,
        'avg_duration': 0,
        'total_solves': 0,
        'total_errors': 0,
      };
    }
  }

  /// Returns cohort data grouped by week for the last [weeks] weeks.
  Future<List<Map<String, dynamic>>> fetchCohortData({int weeks = 8}) async {
    try {
      final since = DateTime.now()
          .subtract(Duration(days: weeks * 7))
          .toIso8601String();
      final rows =
          await _client
                  .from('user_cohorts')
                  .select(
                    'cohort_week, cohort_month, signup_platform, total_solves, total_purchases, total_spent_usd, first_solve_at, first_purchase_at',
                  )
                  .gte('created_at', since)
                  .order('cohort_week', ascending: false)
              as List<dynamic>;

      // Group by cohort_week
      final Map<String, Map<String, dynamic>> grouped = {};
      for (final r in rows) {
        final week = r['cohort_week'] as String? ?? 'Unknown';
        if (!grouped.containsKey(week)) {
          grouped[week] = {
            'cohort_week': week,
            'cohort_month': r['cohort_month'],
            'users': 0,
            'total_solves': 0,
            'total_purchases': 0,
            'total_spent_usd': 0.0,
            'activated': 0, // users who solved at least once
            'converted': 0, // users who purchased at least once
          };
        }
        grouped[week]!['users'] = (grouped[week]!['users'] as int) + 1;
        grouped[week]!['total_solves'] =
            (grouped[week]!['total_solves'] as int) +
            (r['total_solves'] as int? ?? 0);
        grouped[week]!['total_purchases'] =
            (grouped[week]!['total_purchases'] as int) +
            (r['total_purchases'] as int? ?? 0);
        grouped[week]!['total_spent_usd'] =
            (grouped[week]!['total_spent_usd'] as double) +
            (r['total_spent_usd'] as num? ?? 0).toDouble();
        if (r['first_solve_at'] != null) {
          grouped[week]!['activated'] =
              (grouped[week]!['activated'] as int) + 1;
        }
        if (r['first_purchase_at'] != null) {
          grouped[week]!['converted'] =
              (grouped[week]!['converted'] as int) + 1;
        }
      }
      return grouped.values.toList();
    } catch (e) {
      debugPrint('[Analytics] fetchCohortData failed: $e');
      return [];
    }
  }

  /// Returns funnel step counts for a named funnel.
  Future<List<Map<String, dynamic>>> fetchFunnelData({
    String funnelName = 'core_conversion',
    int days = 7,
  }) async {
    try {
      final since = DateTime.now()
          .subtract(Duration(days: days))
          .toIso8601String();
      final rows =
          await _client
                  .from('funnel_steps')
                  .select('step_name, step_order')
                  .eq('funnel_name', funnelName)
                  .gte('reached_at', since)
              as List<dynamic>;

      final Map<String, Map<String, dynamic>> grouped = {};
      for (final r in rows) {
        final step = r['step_name'] as String? ?? 'unknown';
        final order = r['step_order'] as int? ?? 0;
        grouped[step] ??= {'step_name': step, 'step_order': order, 'count': 0};
        grouped[step]!['count'] = (grouped[step]!['count'] as int) + 1;
      }

      final list = grouped.values.toList();
      list.sort(
        (a, b) => (a['step_order'] as int).compareTo(b['step_order'] as int),
      );
      return list;
    } catch (e) {
      debugPrint('[Analytics] fetchFunnelData failed: $e');
      return [];
    }
  }

  /// Returns campaign attribution summary grouped by utm_source.
  Future<List<Map<String, dynamic>>> fetchAttributionData({
    int days = 30,
  }) async {
    try {
      final since = DateTime.now()
          .subtract(Duration(days: days))
          .toIso8601String();
      final rows =
          await _client
                  .from('campaign_attributions')
                  .select(
                    'utm_source, utm_medium, utm_campaign, converted, conversion_type',
                  )
                  .gte('created_at', since)
              as List<dynamic>;

      final Map<String, Map<String, dynamic>> grouped = {};
      for (final r in rows) {
        final source = r['utm_source'] as String? ?? 'organic';
        grouped[source] ??= {
          'utm_source': source,
          'utm_medium': r['utm_medium'],
          'utm_campaign': r['utm_campaign'],
          'installs': 0,
          'conversions': 0,
        };
        grouped[source]!['installs'] =
            (grouped[source]!['installs'] as int) + 1;
        if (r['converted'] == true) {
          grouped[source]!['conversions'] =
              (grouped[source]!['conversions'] as int) + 1;
        }
      }

      final list = grouped.values.toList();
      list.sort(
        (a, b) => (b['installs'] as int).compareTo(a['installs'] as int),
      );
      return list;
    } catch (e) {
      debugPrint('[Analytics] fetchAttributionData failed: $e');
      return [];
    }
  }

  /// Returns purchase conversion rate summary.
  Future<Map<String, dynamic>> fetchPurchaseConversionSummary({
    int days = 30,
  }) async {
    try {
      final since = DateTime.now()
          .subtract(Duration(days: days))
          .toIso8601String();
      final rows =
          await _client
                  .from('user_events')
                  .select('event_type, properties')
                  .inFilter('event_type', [
                    'purchase_started',
                    'purchase_completed',
                    'purchase_failed',
                    'purchase_cancelled',
                  ])
                  .gte('created_at', since)
              as List<dynamic>;

      int started = 0;
      int completed = 0;
      int failed = 0;
      int cancelled = 0;
      double totalRevenue = 0;

      for (final r in rows) {
        final type = r['event_type'] as String;
        final props = r['properties'] as Map<String, dynamic>?;
        switch (type) {
          case 'purchase_started':
            started++;
            break;
          case 'purchase_completed':
            completed++;
            totalRevenue += (props?['price_usd'] as num? ?? 0).toDouble();
            break;
          case 'purchase_failed':
            failed++;
            break;
          case 'purchase_cancelled':
            cancelled++;
            break;
        }
      }

      final conversionRate = started > 0
          ? ((completed / started) * 100).round()
          : 0;

      return {
        'started': started,
        'completed': completed,
        'failed': failed,
        'cancelled': cancelled,
        'conversion_rate': conversionRate,
        'total_revenue': totalRevenue,
      };
    } catch (e) {
      debugPrint('[Analytics] fetchPurchaseConversionSummary failed: $e');
      return {
        'started': 0,
        'completed': 0,
        'failed': 0,
        'cancelled': 0,
        'conversion_rate': 0,
        'total_revenue': 0.0,
      };
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  int _isoWeekNumber(DateTime date) {
    final dayOfYear = int.parse(
      date.difference(DateTime(date.year, 1, 1)).inDays.toString(),
    );
    return ((dayOfYear - date.weekday + 10) / 7).floor();
  }
}
