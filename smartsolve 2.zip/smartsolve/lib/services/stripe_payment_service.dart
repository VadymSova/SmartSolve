import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Stripe payment service for crystal purchases.
/// Crystals are ONLY credited after Stripe webhook confirms payment_intent.succeeded.
class StripePaymentService {
  static StripePaymentService? _instance;
  static StripePaymentService get instance =>
      _instance ??= StripePaymentService._();
  StripePaymentService._();

  static const _publishableKey = String.fromEnvironment(
    'STRIPE_PUBLISHABLE_KEY',
    defaultValue: '',
  );

  /// Initialize Stripe with LIVE publishable key
  static Future<void> initialize() async {
    if (_publishableKey.isEmpty) {
      debugPrint('WARNING: STRIPE_PUBLISHABLE_KEY is not set');
      return;
    }
    Stripe.publishableKey = _publishableKey;
    if (kIsWeb) {
      await Stripe.instance.applySettings();
    }
  }

  /// Purchase a crystal pack.
  /// Returns [PaymentResult] indicating success or failure.
  /// Crystals are NOT credited here — they are credited by the Stripe webhook
  /// Edge Function after payment_intent.succeeded is received from Stripe.
  Future<PaymentResult> purchaseCrystalPack({
    required String userId,
    required String userEmail,
    required int crystalAmount,
    required double priceUsd,
    required String packLabel,
  }) async {
    if (_publishableKey.isEmpty) {
      return PaymentResult.failure(
        'Stripe is not configured. Please contact support.',
      );
    }

    final amountCents = (priceUsd * 100).round();

    try {
      // Step 1: Create payment intent via Supabase Edge Function
      // Backend validates the amount — client cannot manipulate price
      final response = await Supabase.instance.client.functions.invoke(
        'create-payment-intent',
        body: {
          'userId': userId,
          'userEmail': userEmail,
          'crystalAmount': crystalAmount,
          'amountCents': amountCents,
          'currency': 'usd',
          'packLabel': packLabel,
        },
      );

      if (response.status != 200) {
        final errorMsg =
            response.data?['error'] ?? 'Failed to initialize payment';
        return PaymentResult.failure(errorMsg as String);
      }

      final clientSecret = response.data['clientSecret'] as String?;
      if (clientSecret == null || clientSecret.isEmpty) {
        return PaymentResult.failure('Invalid payment session. Please retry.');
      }

      // Capture the payment intent ID for the confirmation screen
      final paymentIntentId = response.data['paymentIntentId'] as String? ?? '';

      // Step 2: Initialize payment sheet
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'SmartSolve',
          style: ThemeMode.dark,
          appearance: const PaymentSheetAppearance(
            colors: PaymentSheetAppearanceColors(
              primary: Color(0xFF7C3AED),
              background: Color(0xFF1A1A2E),
              componentBackground: Color(0xFF16213E),
              primaryText: Color(0xFFFFFFFF),
              secondaryText: Color(0xFFB0B0C0),
            ),
          ),
          googlePay: const PaymentSheetGooglePay(
            merchantCountryCode: 'US',
            currencyCode: 'usd',
            testEnv: false, // LIVE mode
          ),
          applePay: const PaymentSheetApplePay(merchantCountryCode: 'US'),
        ),
      );

      // Step 3: Present payment sheet to user
      await Stripe.instance.presentPaymentSheet();

      // Step 4: Payment sheet dismissed successfully
      // NOTE: Crystals are NOT credited here.
      // The Stripe webhook (stripe-webhook Edge Function) receives
      // payment_intent.succeeded from Stripe and credits crystals via
      // the credit_crystals_on_payment database function.
      return PaymentResult.pendingWebhook(
        message: 'Payment successful! Your crystals will be credited shortly.',
        crystalAmount: crystalAmount,
        transactionId: paymentIntentId,
      );
    } on StripeException catch (e) {
      final code = e.error.code;
      if (code == FailureCode.Canceled) {
        return PaymentResult.cancelled();
      }
      debugPrint('Stripe error: ${e.error.message}');
      return PaymentResult.failure(
        e.error.localizedMessage ?? 'Payment failed. Please try again.',
      );
    } catch (e) {
      debugPrint('Payment error: $e');
      return PaymentResult.failure('Payment failed. Please try again.');
    }
  }

  /// Fetch current crystal balance from Supabase
  Future<int> getCrystalBalance(String userId) async {
    try {
      final response = await Supabase.instance.client
          .from('crystals')
          .select('balance')
          .eq('user_id', userId)
          .maybeSingle();

      return (response?['balance'] as int?) ?? 0;
    } catch (e) {
      debugPrint('Failed to fetch crystal balance: $e');
      return 0;
    }
  }

  /// Deduct crystals for an AI solution (10 crystals per solution)
  Future<bool> deductCrystals(String userId, {int amount = 10}) async {
    try {
      final result = await Supabase.instance.client.rpc(
        'deduct_crystals',
        params: {'p_user_id': userId, 'p_amount': amount},
      );
      return result as bool? ?? false;
    } catch (e) {
      debugPrint('Failed to deduct crystals: $e');
      return false;
    }
  }
}

/// Result of a payment attempt
class PaymentResult {
  final PaymentStatus status;
  final String message;
  final int crystalAmount;
  final String transactionId;

  const PaymentResult._({
    required this.status,
    required this.message,
    this.crystalAmount = 0,
    this.transactionId = '',
  });

  factory PaymentResult.pendingWebhook({
    required String message,
    required int crystalAmount,
    String transactionId = '',
  }) => PaymentResult._(
    status: PaymentStatus.pendingWebhook,
    message: message,
    crystalAmount: crystalAmount,
    transactionId: transactionId,
  );

  factory PaymentResult.failure(String message) =>
      PaymentResult._(status: PaymentStatus.failed, message: message);

  factory PaymentResult.cancelled() => PaymentResult._(
    status: PaymentStatus.cancelled,
    message: 'Payment cancelled.',
  );

  bool get isSuccess => status == PaymentStatus.pendingWebhook;
  bool get isCancelled => status == PaymentStatus.cancelled;
  bool get isFailed => status == PaymentStatus.failed;
}

enum PaymentStatus { pendingWebhook, failed, cancelled }
