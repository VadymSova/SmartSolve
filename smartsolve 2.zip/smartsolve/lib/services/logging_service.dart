import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum LogLevel { debug, info, warning, error, critical }

enum LogCategory { crash, apiError, userFailure, network, auth, unknown }

extension LogLevelExt on LogLevel {
  String get value {
    switch (this) {
      case LogLevel.debug:
        return 'debug';
      case LogLevel.info:
        return 'info';
      case LogLevel.warning:
        return 'warning';
      case LogLevel.error:
        return 'error';
      case LogLevel.critical:
        return 'critical';
    }
  }
}

extension LogCategoryExt on LogCategory {
  String get value {
    switch (this) {
      case LogCategory.crash:
        return 'crash';
      case LogCategory.apiError:
        return 'api_error';
      case LogCategory.userFailure:
        return 'user_failure';
      case LogCategory.network:
        return 'network';
      case LogCategory.auth:
        return 'auth';
      case LogCategory.unknown:
        return 'unknown';
    }
  }
}

class AppLog {
  final String id;
  final String? userId;
  final LogLevel level;
  final LogCategory category;
  final String message;
  final Map<String, dynamic>? details;
  final String? stackTrace;
  final String? platform;
  final DateTime createdAt;

  const AppLog({
    required this.id,
    this.userId,
    required this.level,
    required this.category,
    required this.message,
    this.details,
    this.stackTrace,
    this.platform,
    required this.createdAt,
  });

  factory AppLog.fromJson(Map<String, dynamic> json) {
    LogLevel level = LogLevel.error;
    for (final l in LogLevel.values) {
      if (l.value == json['level']) {
        level = l;
        break;
      }
    }
    LogCategory category = LogCategory.unknown;
    for (final c in LogCategory.values) {
      if (c.value == json['category']) {
        category = c;
        break;
      }
    }
    return AppLog(
      id: json['id'] as String,
      userId: json['user_id'] as String?,
      level: level,
      category: category,
      message: json['message'] as String,
      details: json['details'] as Map<String, dynamic>?,
      stackTrace: json['stack_trace'] as String?,
      platform: json['platform'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }
}

class LoggingService {
  static LoggingService? _instance;
  static LoggingService get instance => _instance ??= LoggingService._();
  LoggingService._();

  SupabaseClient get _client => Supabase.instance.client;

  String get _platform {
    if (kIsWeb) return 'web';
    return defaultTargetPlatform.name.toLowerCase();
  }

  String? get _userId {
    try {
      return _client.auth.currentUser?.id;
    } catch (_) {
      return null;
    }
  }

  /// Log a crash (unhandled exception / Flutter error)
  Future<void> logCrash(
    String message, {
    dynamic error,
    StackTrace? stackTrace,
    Map<String, dynamic>? extra,
  }) async {
    await _log(
      level: LogLevel.critical,
      category: LogCategory.crash,
      message: message,
      error: error,
      stackTrace: stackTrace,
      extra: extra,
    );
  }

  /// Log an API error (Supabase, Lambda, network)
  Future<void> logApiError(
    String message, {
    dynamic error,
    StackTrace? stackTrace,
    Map<String, dynamic>? extra,
  }) async {
    await _log(
      level: LogLevel.error,
      category: LogCategory.apiError,
      message: message,
      error: error,
      stackTrace: stackTrace,
      extra: extra,
    );
  }

  /// Log a user-facing failure (e.g. camera denied, solve failed)
  Future<void> logUserFailure(
    String message, {
    dynamic error,
    Map<String, dynamic>? extra,
  }) async {
    await _log(
      level: LogLevel.warning,
      category: LogCategory.userFailure,
      message: message,
      error: error,
      extra: extra,
    );
  }

  /// Log a network error
  Future<void> logNetworkError(
    String message, {
    dynamic error,
    Map<String, dynamic>? extra,
  }) async {
    await _log(
      level: LogLevel.error,
      category: LogCategory.network,
      message: message,
      error: error,
      extra: extra,
    );
  }

  /// Log an auth error
  Future<void> logAuthError(
    String message, {
    dynamic error,
    Map<String, dynamic>? extra,
  }) async {
    await _log(
      level: LogLevel.error,
      category: LogCategory.auth,
      message: message,
      error: error,
      extra: extra,
    );
  }

  Future<void> _log({
    required LogLevel level,
    required LogCategory category,
    required String message,
    dynamic error,
    StackTrace? stackTrace,
    Map<String, dynamic>? extra,
  }) async {
    // Always print to console in debug
    debugPrint(
      '[${level.value.toUpperCase()}][${category.value}] $message'
      '${error != null ? '\n  Error: $error' : ''}',
    );

    try {
      final details = <String, dynamic>{};
      if (error != null) details['error'] = error.toString();
      if (extra != null) details.addAll(extra);

      await _client.from('app_logs').insert({
        'user_id': _userId,
        'level': level.value,
        'category': category.value,
        'message': message,
        'details': details.isEmpty ? null : details,
        'stack_trace': stackTrace?.toString(),
        'platform': _platform,
      });
    } catch (e) {
      // Never let logging itself crash the app
      debugPrint('[LoggingService] Failed to persist log: $e');
    }
  }

  /// Fetch logs for the admin dashboard
  Future<List<AppLog>> fetchLogs({
    int limit = 50,
    int offset = 0,
    LogCategory? category,
    LogLevel? level,
  }) async {
    try {
      var query = _client
          .from('app_logs')
          .select()
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      final response = await query;
      final rows = response as List<dynamic>;
      return rows
          .map((r) => AppLog.fromJson(r as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('[LoggingService] fetchLogs error: $e');
      return [];
    }
  }

  /// Total log count for the current user
  Future<int> fetchLogCount() async {
    try {
      final response = await _client
          .from('app_logs')
          .select()
          .count(CountOption.exact);
      return response.count;
    } catch (e) {
      return 0;
    }
  }
}
