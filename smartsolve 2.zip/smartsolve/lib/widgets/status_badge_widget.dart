import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';

enum BadgeStatus { success, warning, error, info, primary, muted }

class StatusBadgeWidget extends StatelessWidget {
  final String label;
  final BadgeStatus status;
  final double? fontSize;

  const StatusBadgeWidget({
    super.key,
    required this.label,
    this.status = BadgeStatus.primary,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    final colors = _resolveColors();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: colors.$1,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: colors.$2, width: 1),
      ),
      child: Text(
        label,
        style: GoogleFonts.outfit(
          fontSize: fontSize ?? 11,
          fontWeight: FontWeight.w600,
          color: colors.$3,
          letterSpacing: 0.3,
        ),
      ),
    );
  }

  (Color, Color, Color) _resolveColors() {
    switch (status) {
      case BadgeStatus.success:
        return (
          AppTheme.success.withAlpha(38),
          AppTheme.success.withAlpha(102),
          AppTheme.success,
        );
      case BadgeStatus.warning:
        return (
          AppTheme.warning.withAlpha(38),
          AppTheme.warning.withAlpha(102),
          AppTheme.crystalAccent,
        );
      case BadgeStatus.error:
        return (
          AppTheme.error.withAlpha(38),
          AppTheme.error.withAlpha(102),
          AppTheme.error,
        );
      case BadgeStatus.info:
        return (
          AppTheme.info.withAlpha(38),
          AppTheme.info.withAlpha(102),
          AppTheme.info,
        );
      case BadgeStatus.primary:
        return (
          AppTheme.primary.withAlpha(38),
          AppTheme.primary.withAlpha(102),
          AppTheme.primaryLight,
        );
      case BadgeStatus.muted:
        return (
          AppTheme.surfaceVariantDark,
          AppTheme.surfaceElevatedDark,
          AppTheme.textSecondary,
        );
    }
  }
}
