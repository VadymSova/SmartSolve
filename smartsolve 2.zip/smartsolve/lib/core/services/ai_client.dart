import 'package:dio/dio.dart';

import '../../services/logging_service.dart';

final Dio _dio = Dio(
  BaseOptions(
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(seconds: 60),
    sendTimeout: const Duration(seconds: 30),
  ),
);

String _friendlyErrorMessage(dynamic error) {
  if (error is DioException) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Request timed out. Please check your connection and try again.';
      case DioExceptionType.connectionError:
        return 'No internet connection. Please check your network and try again.';
      case DioExceptionType.badResponse:
        final status = error.response?.statusCode;
        if (status == 429) {
          return 'Too many requests. Please wait a moment and try again.';
        }
        if (status != null && status >= 500) {
          return 'Server error. Please try again in a moment.';
        }
        if (status == 401 || status == 403) {
          return 'Authentication error. Please restart the app.';
        }
        return 'Something went wrong (error $status). Please try again.';
      default:
        return 'Connection failed. Please try again.';
    }
  }
  return 'An unexpected error occurred. Please try again.';
}

Future<Map<String, dynamic>> callLambdaFunction(
  String endpoint,
  Map<String, dynamic> payload,
) async {
  try {
    final response = await _dio.post<Map<String, dynamic>>(
      endpoint,
      data: payload,
      options: Options(headers: {'Content-Type': 'application/json'}),
    );
    return response.data ?? {};
  } on DioException catch (error) {
    if (error.response?.data != null && error.response?.data is Map) {
      final data = error.response?.data as Map<String, dynamic>;
      if (data['error'] != null) {
        LoggingService.instance.logApiError(
          'Lambda API error: ${data['error']}',
          error: error,
          extra: {'endpoint': endpoint, 'status': error.response?.statusCode},
        );
        throw Exception(data['error'].toString());
      }
    }
    final msg = _friendlyErrorMessage(error);
    final isNetwork =
        error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout;
    if (isNetwork) {
      LoggingService.instance.logNetworkError(
        'Lambda network error: $msg',
        error: error,
        extra: {'endpoint': endpoint},
      );
    } else {
      LoggingService.instance.logApiError(
        'Lambda DioException: $msg',
        error: error,
        extra: {'endpoint': endpoint, 'status': error.response?.statusCode},
      );
    }
    throw Exception(msg);
  } catch (e) {
    LoggingService.instance.logCrash(
      'Lambda unexpected error',
      error: e,
      extra: {'endpoint': endpoint},
    );
    throw Exception('An unexpected error occurred. Please try again.');
  }
}

bool isTimeoutError(Exception error) {
  final msg = error.toString().toLowerCase();
  return msg.contains('timed out') ||
      msg.contains('timeout') ||
      msg.contains('connection');
}