import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/services/aiIntegrations/chat_completion_service.dart';
import '../services/logging_service.dart';

class ChatConfig {
  final String provider;
  final String model;
  final bool streaming;

  const ChatConfig({
    required this.provider,
    required this.model,
    this.streaming = true,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ChatConfig &&
          provider == other.provider &&
          model == other.model &&
          streaming == other.streaming;

  @override
  int get hashCode => provider.hashCode ^ model.hashCode ^ streaming.hashCode;
}

class ChatState {
  final String response;
  final dynamic fullResponse;
  final bool isLoading;
  final Exception? error;

  const ChatState({
    this.response = '',
    this.fullResponse,
    this.isLoading = false,
    this.error,
  });

  ChatState copyWith({
    String? response,
    dynamic fullResponse,
    bool? isLoading,
    Exception? error,
    bool clearError = false,
  }) {
    return ChatState(
      response: response ?? this.response,
      fullResponse: fullResponse ?? this.fullResponse,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : (error ?? this.error),
    );
  }
}

class ChatNotifier extends StateNotifier<ChatState> {
  final String provider;
  final String model;
  final bool streaming;

  ChatNotifier({
    required this.provider,
    required this.model,
    this.streaming = true,
  }) : super(const ChatState());

  Future<void> sendMessage(
    List<Map<String, dynamic>> messages, {
    Map<String, dynamic> parameters = const {},
  }) async {
    state = ChatState(
      response: '',
      fullResponse: streaming ? <Map<String, dynamic>>[] : null,
      isLoading: true,
    );

    try {
      if (streaming) {
        await getStreamingChatCompletion(
          provider,
          model,
          messages,
          onChunk: (chunk) {
            final chunks = List<Map<String, dynamic>>.from(
              state.fullResponse as List? ?? [],
            )..add(chunk);
            final content =
                chunk['choices']?[0]?['delta']?['content'] as String?;
            state = state.copyWith(
              fullResponse: chunks,
              response: content != null
                  ? state.response + content
                  : state.response,
            );
          },
          onComplete: () => state = state.copyWith(isLoading: false),
          onError: (error) {
            final raw = error.toString();
            final message = raw.startsWith('Exception: ')
                ? raw.replaceFirst('Exception: ', '')
                : 'Something went wrong. Please try again.';
            LoggingService.instance.logApiError(
              'Streaming chat error: $message',
              error: error,
              extra: {'provider': provider, 'model': model},
            );
            state = state.copyWith(error: Exception(message), isLoading: false);
          },
          parameters: parameters,
        );
      } else {
        final result = await getChatCompletion(
          provider,
          model,
          messages,
          parameters: parameters,
        );
        final content =
            result['choices']?[0]?['message']?['content'] as String? ?? '';
        state = ChatState(
          response: content,
          fullResponse: result,
          isLoading: false,
        );
      }
    } catch (error) {
      final raw = error.toString();
      String message;
      if (raw.toLowerCase().contains('timeout') ||
          raw.toLowerCase().contains('timed out')) {
        message =
            'Request timed out. Please check your connection and try again.';
        LoggingService.instance.logNetworkError(
          'Chat completion timeout',
          error: error,
          extra: {'provider': provider, 'model': model},
        );
      } else if (raw.toLowerCase().contains('socket') ||
          raw.toLowerCase().contains('network') ||
          raw.toLowerCase().contains('connection')) {
        message =
            'No internet connection. Please check your network and try again.';
        LoggingService.instance.logNetworkError(
          'Chat completion network error',
          error: error,
          extra: {'provider': provider, 'model': model},
        );
      } else if (raw.startsWith('Exception: ')) {
        message = raw.replaceFirst('Exception: ', '');
        LoggingService.instance.logApiError(
          'Chat completion API error: $message',
          error: error,
          extra: {'provider': provider, 'model': model},
        );
      } else {
        message = 'Something went wrong. Please try again.';
        LoggingService.instance.logApiError(
          'Chat completion unknown error',
          error: error,
          extra: {'provider': provider, 'model': model},
        );
      }
      state = state.copyWith(error: Exception(message), isLoading: false);
    }
  }

  void clearResponse() => state = const ChatState();
}

final chatNotifierProvider =
    StateNotifierProvider.family<ChatNotifier, ChatState, ChatConfig>(
      (ref, config) => ChatNotifier(
        provider: config.provider,
        model: config.model,
        streaming: config.streaming,
      ),
    );
