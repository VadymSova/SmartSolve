import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { imageBase64, question } = body;

    if (!imageBase64 && !question) {
      return new Response(
        JSON.stringify({ error: "Either imageBase64 or question is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const openaiApiKey = Deno.env.get("OPENAI_API_KEY");
    if (!openaiApiKey) {
      return new Response(
        JSON.stringify({ error: "OPENAI_API_KEY is not configured" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const systemPrompt =
      "You are a precise homework solver and academic tutor. " +
      "Solve problems step by step. " +
      "For math: show every calculation step, never approximate, 2+2=4 exactly. " +
      "For science: explain concepts clearly and provide accurate answers. " +
      "For language/writing: provide corrections and explanations. " +
      "Format your response clearly with numbered steps where applicable. " +
      "Answer in the same language as the question.";

    // Build user message content
    let userContent: unknown;
    if (imageBase64) {
      // Image-based question (with optional text)
      userContent = [
        {
          type: "text",
          text: question ?? "Please solve this homework problem. Show all steps clearly.",
        },
        {
          type: "image_url",
          image_url: {
            url: imageBase64,
            detail: "high",
          },
        },
      ];
    } else {
      // Text-only question
      userContent = question;
    }

    const openaiResponse = await fetch(
      "https://api.openai.com/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${openaiApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: systemPrompt,
            },
            {
              role: "user",
              content: userContent,
            },
          ],
          max_tokens: 2000,
        }),
      }
    );

    if (!openaiResponse.ok) {
      const errorBody = await openaiResponse.text();
      console.error("OpenAI error:", errorBody);
      return new Response(
        JSON.stringify({
          error: `OpenAI API error: ${openaiResponse.status}`,
          details: errorBody,
        }),
        {
          status: openaiResponse.status,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const openaiData = await openaiResponse.json();
    const solution =
      openaiData?.choices?.[0]?.message?.content ?? "No solution returned.";

    return new Response(JSON.stringify({ solution }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("solve-homework error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error", details: String(error) }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
