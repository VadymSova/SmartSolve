import Stripe from 'https://esm.sh/stripe@14.21.0'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') ?? '', {
      apiVersion: '2024-06-20',
    })

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { userId, userEmail, crystalAmount, amountCents, currency, packLabel } = await req.json()

    if (!userId || !crystalAmount || !amountCents) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: userId, crystalAmount, amountCents' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Validate amount on backend (never trust client)
    const validPacks: Record<number, number> = {
      100: 99,   // $0.99
      500: 399,  // $3.99
      1000: 699, // $6.99
    }

    if (!validPacks[crystalAmount] || validPacks[crystalAmount] !== amountCents) {
      return new Response(
        JSON.stringify({ error: 'Invalid crystal pack or amount mismatch' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Create or retrieve Stripe customer
    let stripeCustomerId: string | undefined

    const { data: existingTx } = await supabase
      .from('crystal_transactions')
      .select('stripe_customer_id')
      .eq('user_id', userId)
      .not('stripe_customer_id', 'is', null)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (existingTx?.stripe_customer_id) {
      stripeCustomerId = existingTx.stripe_customer_id
    } else {
      const customer = await stripe.customers.create({
        email: userEmail ?? undefined,
        metadata: { supabase_user_id: userId },
      })
      stripeCustomerId = customer.id
    }

    // Create Payment Intent (LIVE mode uses live keys automatically)
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency: currency ?? 'usd',
      customer: stripeCustomerId,
      description: `SmartSolve - ${packLabel ?? `${crystalAmount} Crystals`}`,
      metadata: {
        supabase_user_id: userId,
        crystal_amount: String(crystalAmount),
        pack_label: packLabel ?? '',
      },
      automatic_payment_methods: { enabled: true },
    })

    // Save pending transaction record BEFORE returning clientSecret
    const { error: insertError } = await supabase
      .from('crystal_transactions')
      .insert({
        user_id: userId,
        payment_intent_id: paymentIntent.id,
        stripe_customer_id: stripeCustomerId,
        crystal_amount: crystalAmount,
        amount_cents: amountCents,
        currency: currency ?? 'usd',
        payment_status: 'pending',
        pack_label: packLabel ?? '',
      })

    if (insertError) {
      console.error('Failed to save transaction:', insertError)
      // Cancel the payment intent to avoid orphaned charges
      await stripe.paymentIntents.cancel(paymentIntent.id)
      return new Response(
        JSON.stringify({ error: 'Failed to create transaction record' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('create-payment-intent error:', error)
    return new Response(
      JSON.stringify({ error: 'Payment initialization failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
