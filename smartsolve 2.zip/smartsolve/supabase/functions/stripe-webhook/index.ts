import Stripe from 'https://esm.sh/stripe@14.21.0'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, stripe-signature',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') ?? '', {
    apiVersion: '2024-06-20',
  })

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  )

  const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET') ?? ''
  const signature = req.headers.get('stripe-signature') ?? ''
  const body = await req.text()

  let event: Stripe.Event

  try {
    // Verify webhook signature — CRITICAL for security
    event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret)
  } catch (err) {
    console.error('Webhook signature verification failed:', err)
    return new Response(
      JSON.stringify({ error: 'Invalid webhook signature' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  console.log(`Stripe webhook event: ${event.type}`)

  try {
    if (event.type === 'payment_intent.succeeded') {
      const paymentIntent = event.data.object as Stripe.PaymentIntent

      const userId = paymentIntent.metadata?.supabase_user_id
      const crystalAmount = parseInt(paymentIntent.metadata?.crystal_amount ?? '0', 10)

      if (!userId || !crystalAmount) {
        console.error('Missing metadata in payment intent:', paymentIntent.id)
        return new Response(
          JSON.stringify({ error: 'Missing metadata' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Credit crystals using the secure database function
      // This is the ONLY place crystals are credited — after real payment confirmation
      const { data: credited, error: creditError } = await supabase.rpc('credit_crystals_on_payment', {
        p_payment_intent_id: paymentIntent.id,
        p_user_id: userId,
        p_crystal_amount: crystalAmount,
      })

      if (creditError) {
        console.error('Failed to credit crystals:', creditError)
        return new Response(
          JSON.stringify({ error: 'Failed to credit crystals' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      if (!credited) {
        console.warn('Crystal credit returned false (already processed or not found):', paymentIntent.id)
      } else {
        console.log(`Credited ${crystalAmount} crystals to user ${userId} for payment ${paymentIntent.id}`)
      }
    } else if (event.type === 'payment_intent.payment_failed') {
      const paymentIntent = event.data.object as Stripe.PaymentIntent

      // Mark transaction as failed
      await supabase
        .from('crystal_transactions')
        .update({ payment_status: 'failed' })
        .eq('payment_intent_id', paymentIntent.id)
        .eq('payment_status', 'pending')

      console.log(`Payment failed for intent: ${paymentIntent.id}`)
    } else if (event.type === 'charge.refunded') {
      const charge = event.data.object as Stripe.Charge
      const paymentIntentId = charge.payment_intent as string

      if (paymentIntentId) {
        // Mark transaction as refunded (crystals are NOT deducted back automatically)
        await supabase
          .from('crystal_transactions')
          .update({ payment_status: 'refunded' })
          .eq('payment_intent_id', paymentIntentId)

        console.log(`Refund recorded for payment intent: ${paymentIntentId}`)
      }
    }

    return new Response(
      JSON.stringify({ received: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Webhook handler error:', error)
    return new Response(
      JSON.stringify({ error: 'Webhook processing failed' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
