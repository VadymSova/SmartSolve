-- Ensure handle_new_user trigger function is up to date
-- and backfill any auth users that don't have a user_profiles row yet

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, avatar_url)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', '')
    )
    ON CONFLICT (id) DO NOTHING;

    -- Initialize crystal balance with 50 free crystals (5 free solutions)
    INSERT INTO public.crystals (user_id, balance)
    VALUES (NEW.id, 50)
    ON CONFLICT DO NOTHING;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Backfill: create user_profiles for any auth users that don't have one yet
DO $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, avatar_url)
    SELECT
        au.id,
        au.email,
        COALESCE(au.raw_user_meta_data->>'full_name', split_part(au.email, '@', 1)),
        COALESCE(au.raw_user_meta_data->>'avatar_url', '')
    FROM auth.users au
    WHERE NOT EXISTS (
        SELECT 1 FROM public.user_profiles up WHERE up.id = au.id
    )
    ON CONFLICT (id) DO NOTHING;

    -- Backfill crystals for users without a balance row
    INSERT INTO public.crystals (user_id, balance)
    SELECT up.id, 50
    FROM public.user_profiles up
    WHERE NOT EXISTS (
        SELECT 1 FROM public.crystals c WHERE c.user_id = up.id
    )
    ON CONFLICT DO NOTHING;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Backfill skipped: %', SQLERRM;
END $$;
