-- Crystal economy tables with Stripe payment verification
-- Crystals are ONLY credited after Stripe webhook confirms payment

-- 1. User profiles table (intermediary for auth.users)
CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Crystals balance table
CREATE TABLE IF NOT EXISTS public.crystals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    balance INTEGER NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT crystals_balance_non_negative CHECK (balance >= 0)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_crystals_user_id ON public.crystals(user_id);
CREATE INDEX IF NOT EXISTS idx_crystals_user_id_lookup ON public.crystals(user_id);

-- 3. Crystal transactions table (tracks all purchases, pending until webhook confirms)
CREATE TABLE IF NOT EXISTS public.crystal_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    payment_intent_id TEXT NOT NULL UNIQUE,
    stripe_customer_id TEXT,
    crystal_amount INTEGER NOT NULL,
    amount_cents INTEGER NOT NULL,
    currency TEXT NOT NULL DEFAULT 'usd',
    payment_status TEXT NOT NULL DEFAULT 'pending',
    pack_label TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMPTZ,
    CONSTRAINT valid_payment_status CHECK (payment_status IN ('pending', 'succeeded', 'failed', 'refunded'))
);

CREATE INDEX IF NOT EXISTS idx_crystal_transactions_user_id ON public.crystal_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_crystal_transactions_payment_intent ON public.crystal_transactions(payment_intent_id);

-- 4. Solutions table (tracks AI usage)
CREATE TABLE IF NOT EXISTS public.solutions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    question TEXT NOT NULL,
    response TEXT,
    subject TEXT,
    crystals_used INTEGER NOT NULL DEFAULT 10,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_solutions_user_id ON public.solutions(user_id);

-- 5. Functions

-- Auto-create user_profiles on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, avatar_url)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'avatar_url', '')
    )
    ON CONFLICT (id) DO NOTHING;

    -- Initialize crystal balance with 50 free crystals (5 free solutions)
    INSERT INTO public.crystals (user_id, balance)
    VALUES (NEW.id, 50)
    ON CONFLICT DO NOTHING;

    RETURN NEW;
END;
$$;

-- Function to credit crystals after confirmed payment (called by webhook edge function)
CREATE OR REPLACE FUNCTION public.credit_crystals_on_payment(
    p_payment_intent_id TEXT,
    p_user_id UUID,
    p_crystal_amount INTEGER
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_transaction_status TEXT;
BEGIN
    -- Check transaction exists and is still pending
    SELECT payment_status INTO v_transaction_status
    FROM public.crystal_transactions
    WHERE payment_intent_id = p_payment_intent_id
      AND user_id = p_user_id
    LIMIT 1;

    IF v_transaction_status IS NULL THEN
        RAISE NOTICE 'Transaction not found: %', p_payment_intent_id;
        RETURN FALSE;
    END IF;

    IF v_transaction_status != 'pending' THEN
        RAISE NOTICE 'Transaction already processed: % status=%', p_payment_intent_id, v_transaction_status;
        RETURN FALSE;
    END IF;

    -- Mark transaction as succeeded
    UPDATE public.crystal_transactions
    SET payment_status = 'succeeded',
        confirmed_at = NOW()
    WHERE payment_intent_id = p_payment_intent_id
      AND user_id = p_user_id
      AND payment_status = 'pending';

    -- Credit crystals to user balance
    INSERT INTO public.crystals (user_id, balance)
    VALUES (p_user_id, p_crystal_amount)
    ON CONFLICT (user_id) DO UPDATE
        SET balance = public.crystals.balance + p_crystal_amount,
            updated_at = NOW();

    RETURN TRUE;
END;
$$;

-- Function to deduct crystals for AI solution
CREATE OR REPLACE FUNCTION public.deduct_crystals(
    p_user_id UUID,
    p_amount INTEGER
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_balance INTEGER;
BEGIN
    SELECT balance INTO v_balance
    FROM public.crystals
    WHERE user_id = p_user_id
    LIMIT 1;

    IF v_balance IS NULL OR v_balance < p_amount THEN
        RETURN FALSE;
    END IF;

    UPDATE public.crystals
    SET balance = balance - p_amount,
        updated_at = NOW()
    WHERE user_id = p_user_id
      AND balance >= p_amount;

    RETURN FOUND;
END;
$$;

-- 6. Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crystals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.crystal_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.solutions ENABLE ROW LEVEL SECURITY;

-- 7. RLS Policies

DROP POLICY IF EXISTS "users_manage_own_user_profiles" ON public.user_profiles;
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles FOR ALL TO authenticated
USING (id = auth.uid()) WITH CHECK (id = auth.uid());

DROP POLICY IF EXISTS "users_read_own_crystals" ON public.crystals;
CREATE POLICY "users_read_own_crystals"
ON public.crystals FOR SELECT TO authenticated
USING (user_id = auth.uid());

DROP POLICY IF EXISTS "service_manage_crystals" ON public.crystals;
CREATE POLICY "service_manage_crystals"
ON public.crystals FOR ALL TO service_role
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "users_read_own_transactions" ON public.crystal_transactions;
CREATE POLICY "users_read_own_transactions"
ON public.crystal_transactions FOR SELECT TO authenticated
USING (user_id = auth.uid());

DROP POLICY IF EXISTS "users_insert_own_transactions" ON public.crystal_transactions;
CREATE POLICY "users_insert_own_transactions"
ON public.crystal_transactions FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "service_manage_transactions" ON public.crystal_transactions;
CREATE POLICY "service_manage_transactions"
ON public.crystal_transactions FOR ALL TO service_role
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "users_manage_own_solutions" ON public.solutions;
CREATE POLICY "users_manage_own_solutions"
ON public.solutions FOR ALL TO authenticated
USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- 8. Triggers
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
