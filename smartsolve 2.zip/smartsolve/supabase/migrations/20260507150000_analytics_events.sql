-- ============================================================
-- Analytics: user_events + session_metrics
-- ============================================================

-- 1. TYPES
DROP TYPE IF EXISTS public.event_type CASCADE;
CREATE TYPE public.event_type AS ENUM (
  'auth_sign_in',
  'auth_sign_up',
  'auth_sign_out',
  'auth_error',
  'solve_started',
  'solve_completed',
  'solve_failed',
  'solve_retried',
  'camera_opened',
  'camera_captured',
  'gallery_picked',
  'purchase_started',
  'purchase_completed',
  'purchase_failed',
  'purchase_cancelled',
  'error_crash',
  'error_api',
  'error_network',
  'session_start',
  'session_end'
);

-- 2. TABLES

CREATE TABLE IF NOT EXISTS public.user_events (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  event_type    public.event_type NOT NULL,
  properties    JSONB,
  platform      TEXT,
  app_version   TEXT,
  created_at    TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.session_metrics (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  session_id      TEXT NOT NULL,
  started_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at        TIMESTAMPTZ,
  duration_secs   INTEGER,
  solves_count    INTEGER DEFAULT 0,
  errors_count    INTEGER DEFAULT 0,
  platform        TEXT,
  created_at      TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. INDEXES
CREATE INDEX IF NOT EXISTS idx_user_events_user_id    ON public.user_events(user_id);
CREATE INDEX IF NOT EXISTS idx_user_events_type       ON public.user_events(event_type);
CREATE INDEX IF NOT EXISTS idx_user_events_created_at ON public.user_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_session_metrics_user   ON public.session_metrics(user_id);
CREATE INDEX IF NOT EXISTS idx_session_metrics_sid    ON public.session_metrics(session_id);
CREATE INDEX IF NOT EXISTS idx_session_metrics_start  ON public.session_metrics(started_at DESC);

-- 4. ENABLE RLS
ALTER TABLE public.user_events     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.session_metrics ENABLE ROW LEVEL SECURITY;

-- 5. RLS POLICIES

-- user_events: users can insert their own events; admins can read all
DROP POLICY IF EXISTS "users_insert_own_events" ON public.user_events;
CREATE POLICY "users_insert_own_events"
ON public.user_events
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

DROP POLICY IF EXISTS "users_select_own_events" ON public.user_events;
CREATE POLICY "users_select_own_events"
ON public.user_events
FOR SELECT
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL);

-- Allow anon inserts for pre-auth events (sign_in / sign_up attempts)
DROP POLICY IF EXISTS "anon_insert_events" ON public.user_events;
CREATE POLICY "anon_insert_events"
ON public.user_events
FOR INSERT
TO anon
WITH CHECK (user_id IS NULL);

-- session_metrics
DROP POLICY IF EXISTS "users_manage_own_sessions" ON public.session_metrics;
CREATE POLICY "users_manage_own_sessions"
ON public.session_metrics
FOR ALL
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL)
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

DROP POLICY IF EXISTS "anon_insert_sessions" ON public.session_metrics;
CREATE POLICY "anon_insert_sessions"
ON public.session_metrics
FOR INSERT
TO anon
WITH CHECK (user_id IS NULL);
