-- App Logs table for centralized crash, API error, and user failure monitoring

CREATE TABLE IF NOT EXISTS public.app_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    level TEXT NOT NULL DEFAULT 'error',
    category TEXT NOT NULL DEFAULT 'unknown',
    message TEXT NOT NULL,
    details JSONB,
    stack_trace TEXT,
    app_version TEXT,
    platform TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_level CHECK (level IN ('debug', 'info', 'warning', 'error', 'critical')),
    CONSTRAINT valid_category CHECK (category IN ('crash', 'api_error', 'user_failure', 'network', 'auth', 'unknown'))
);

CREATE INDEX IF NOT EXISTS idx_app_logs_user_id ON public.app_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_app_logs_level ON public.app_logs(level);
CREATE INDEX IF NOT EXISTS idx_app_logs_category ON public.app_logs(category);
CREATE INDEX IF NOT EXISTS idx_app_logs_created_at ON public.app_logs(created_at DESC);

-- Enable RLS
ALTER TABLE public.app_logs ENABLE ROW LEVEL SECURITY;

-- Users can insert their own logs
DROP POLICY IF EXISTS "users_insert_own_logs" ON public.app_logs;
CREATE POLICY "users_insert_own_logs"
ON public.app_logs FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

-- Users can read their own logs
DROP POLICY IF EXISTS "users_read_own_logs" ON public.app_logs;
CREATE POLICY "users_read_own_logs"
ON public.app_logs FOR SELECT TO authenticated
USING (user_id = auth.uid());

-- Service role has full access (for admin dashboard)
DROP POLICY IF EXISTS "service_manage_logs" ON public.app_logs;
CREATE POLICY "service_manage_logs"
ON public.app_logs FOR ALL TO service_role
USING (true) WITH CHECK (true);

-- Allow anon inserts for pre-auth crashes
DROP POLICY IF EXISTS "anon_insert_logs" ON public.app_logs;
CREATE POLICY "anon_insert_logs"
ON public.app_logs FOR INSERT TO anon
WITH CHECK (user_id IS NULL);
