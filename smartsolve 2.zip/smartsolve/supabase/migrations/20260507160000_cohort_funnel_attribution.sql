-- ============================================================
-- Cohort Tracking, Funnel Analysis, Purchase Conversion,
-- and Campaign Attribution (UTM parameters)
-- ============================================================

-- 1. TABLES

-- campaign_attributions: stores UTM params captured on first open, linked to user
CREATE TABLE IF NOT EXISTS public.campaign_attributions (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  session_id      TEXT,
  utm_source      TEXT,
  utm_medium      TEXT,
  utm_campaign    TEXT,
  utm_term        TEXT,
  utm_content     TEXT,
  referrer        TEXT,
  first_open_at   TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  converted       BOOLEAN DEFAULT FALSE,
  converted_at    TIMESTAMPTZ,
  conversion_type TEXT,
  platform        TEXT,
  created_at      TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- user_cohorts: weekly/monthly cohort snapshots per user
CREATE TABLE IF NOT EXISTS public.user_cohorts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
  cohort_week     TEXT NOT NULL,
  cohort_month    TEXT NOT NULL,
  signup_platform TEXT,
  signup_method   TEXT,
  first_solve_at  TIMESTAMPTZ,
  first_purchase_at TIMESTAMPTZ,
  total_solves    INTEGER DEFAULT 0,
  total_purchases INTEGER DEFAULT 0,
  total_spent_usd NUMERIC(10,2) DEFAULT 0,
  is_active       BOOLEAN DEFAULT TRUE,
  created_at      TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- funnel_steps: records each step a user passes through in a defined funnel
CREATE TABLE IF NOT EXISTS public.funnel_steps (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
  session_id  TEXT,
  funnel_name TEXT NOT NULL,
  step_name   TEXT NOT NULL,
  step_order  INTEGER NOT NULL,
  reached_at  TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
  platform    TEXT,
  properties  JSONB
);

-- 2. INDEXES
CREATE INDEX IF NOT EXISTS idx_campaign_attr_user_id   ON public.campaign_attributions(user_id);
CREATE INDEX IF NOT EXISTS idx_campaign_attr_source     ON public.campaign_attributions(utm_source);
CREATE INDEX IF NOT EXISTS idx_campaign_attr_created    ON public.campaign_attributions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_cohorts_user_id     ON public.user_cohorts(user_id);
CREATE INDEX IF NOT EXISTS idx_user_cohorts_week        ON public.user_cohorts(cohort_week);
CREATE INDEX IF NOT EXISTS idx_user_cohorts_month       ON public.user_cohorts(cohort_month);
CREATE UNIQUE INDEX IF NOT EXISTS idx_user_cohorts_unique ON public.user_cohorts(user_id);
CREATE INDEX IF NOT EXISTS idx_funnel_steps_user_id     ON public.funnel_steps(user_id);
CREATE INDEX IF NOT EXISTS idx_funnel_steps_funnel      ON public.funnel_steps(funnel_name);
CREATE INDEX IF NOT EXISTS idx_funnel_steps_reached     ON public.funnel_steps(reached_at DESC);

-- 3. ENABLE RLS
ALTER TABLE public.campaign_attributions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_cohorts          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.funnel_steps          ENABLE ROW LEVEL SECURITY;

-- 4. RLS POLICIES

-- campaign_attributions
DROP POLICY IF EXISTS "users_manage_own_attributions" ON public.campaign_attributions;
CREATE POLICY "users_manage_own_attributions"
ON public.campaign_attributions
FOR ALL
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL)
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

DROP POLICY IF EXISTS "anon_insert_attributions" ON public.campaign_attributions;
CREATE POLICY "anon_insert_attributions"
ON public.campaign_attributions
FOR INSERT
TO anon
WITH CHECK (user_id IS NULL);

-- user_cohorts
DROP POLICY IF EXISTS "users_manage_own_cohorts" ON public.user_cohorts;
CREATE POLICY "users_manage_own_cohorts"
ON public.user_cohorts
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- funnel_steps
DROP POLICY IF EXISTS "users_manage_own_funnel_steps" ON public.funnel_steps;
CREATE POLICY "users_manage_own_funnel_steps"
ON public.funnel_steps
FOR ALL
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL)
WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

DROP POLICY IF EXISTS "anon_insert_funnel_steps" ON public.funnel_steps;
CREATE POLICY "anon_insert_funnel_steps"
ON public.funnel_steps
FOR INSERT
TO anon
WITH CHECK (user_id IS NULL);
